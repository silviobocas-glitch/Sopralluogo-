package com.example.sopralluoghi

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider

class FolderActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NOME = "NOME_CARTELLA"
    }

    private lateinit var nomeCartella: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_folder)

        nomeCartella = intent.getStringExtra(EXTRA_NOME) ?: run {
            finish()
            return
        }

        findViewById<TextView>(R.id.tvTitoloCartella).text = nomeCartella
        findViewById<View>(R.id.btnIndietroCartella).setOnClickListener { finish() }

        findViewById<View>(R.id.btnVediFoto).setOnClickListener {
            val intent = Intent(this, GalleryActivity::class.java)
            intent.putExtra(GalleryActivity.EXTRA_NOME_CARTELLA, nomeCartella)
            startActivity(intent)
        }

        findViewById<View>(R.id.btnCondividi).setOnClickListener { condividiCartella() }
    }

    private fun condividiCartella() {
        android.widget.Toast.makeText(this, "Preparo il file da condividere...", android.widget.Toast.LENGTH_SHORT).show()
        Thread {
            val zipFile = ZipHelper.creaZipDiCartella(this, nomeCartella)
            runOnUiThread {
                if (zipFile != null) {
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", zipFile)
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/zip"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(shareIntent, "Condividi $nomeCartella"))
                } else {
                    android.widget.Toast.makeText(this, "Errore nella creazione dello zip", android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
