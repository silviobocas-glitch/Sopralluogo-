package com.example.sopralluoghi

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FolderAdapter(
    private val elenco: List<String>,
    private val onNuovo: () -> Unit,
    private val onApri: (String) -> Unit,
    private val onLongClick: (String) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TIPO_NUOVO = 0
        private const val TIPO_CARTELLA = 1
    }

    class NuovoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    class CartellaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nome: TextView = itemView.findViewById(R.id.tvNomeCartella)
        val sottotitolo: TextView = itemView.findViewById(R.id.tvSottotitoloCartella)
    }

    override fun getItemCount(): Int = elenco.size + 1

    override fun getItemViewType(position: Int): Int =
        if (position == 0) TIPO_NUOVO else TIPO_CARTELLA

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TIPO_NUOVO) {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_new_tile, parent, false)
            NuovoViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder_tile, parent, false)
            CartellaViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is NuovoViewHolder) {
            holder.itemView.setOnClickListener { onNuovo() }
        } else if (holder is CartellaViewHolder) {
            val nome = elenco[position - 1]
            holder.nome.text = nome
            holder.sottotitolo.text = "Tocca per aprire"
            holder.itemView.setOnClickListener { onApri(nome) }
            holder.itemView.setOnLongClickListener {
                onLongClick(nome)
                true
            }
        }
    }
}
