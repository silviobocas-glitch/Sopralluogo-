package com.example.sopralluoghi

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.content.PermissionChecker
import java.io.File
import java.util.Locale

class CameraActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NOME_SOPRALLUOGO = "NOME_SOPRALLUOGO"
        private const val SOTTOCARTELLA = "Sopralluoghi"

        // --- Impostazioni versione di prova ---
        private const val PREFS_TRIAL = "trial_prefs"
        private const val KEY_FOTO_TOTALI = "foto_totali_scattate"
        private const val KEY_SBLOCCATO = "app_sbloccata"
        private const val LIMITE_FOTO_PROVA = 3
        private const val CODICE_SBLOCCO = "Bic26"

        // --- Impostazioni video ---
        private const val DURATA_MASSIMA_VIDEO_MS = 40_000L

        private const val REQUEST_CODE_VISUALIZZA_ELEMENTO = 501
    }

    private lateinit var imageCapture: ImageCapture
    private var videoCapture: VideoCapture<Recorder>? = null
    private var registrazioneInCorso: Recording? = null

    private lateinit var nomeCartella: String
    private var contatore = 0

    private lateinit var trialPrefs: android.content.SharedPreferences
    private var appSbloccata = false
    private var fotoTotaliScattate = 0

    private var camera: Camera? = null
    // Indica solo che il flash è SELEZIONATO dall'utente, non che è fisicamente acceso in questo istante:
    // in foto si accende solo al momento dello scatto, in video resta acceso per tutta la registrazione
    private var flashSelezionato = false
    private var modalitaVideo = false

    // Riferimento all'ultimo elemento salvato (foto o video), per poterlo aprire a schermo intero
    private var ultimoUri: Uri? = null
    private var ultimoFile: File? = null
    private var ultimoNomeFile: String = ""
    private var ultimoEraVideo: Boolean = false

    private lateinit var tvContatore: TextView
    private lateinit var tvZoom: TextView
    private lateinit var btnTorcia: TextView
    private lateinit var frameMiniatura: FrameLayout
    private lateinit var ivMiniatura: ImageView
    private lateinit var btnVideo: Button
    private lateinit var btnFoto: Button
    private lateinit var btnScatta: Button
    private lateinit var viewFlashFoto: View

    private val handlerTimer = Handler(Looper.getMainLooper())
    private var secondiRimanenti = 40
    private val runnableTimer = object : Runnable {
        override fun run() {
            secondiRimanenti -= 1
            aggiornaTestoTimer()
            if (secondiRimanenti > 0 && registrazioneInCorso != null) {
                handlerTimer.postDelayed(this, 1000)
            }
        }
    }

    private val scaleGestureDetector by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val zoomAttuale = cam.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                val nuovoZoom = zoomAttuale * detector.scaleFactor
                cam.cameraControl.setZoomRatio(nuovoZoom)
                return true
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera)

        nomeCartella = intent.getStringExtra(EXTRA_NOME_SOPRALLUOGO) ?: "Sopralluogo"

        trialPrefs = getSharedPreferences(PREFS_TRIAL, Context.MODE_PRIVATE)
        appSbloccata = trialPrefs.getBoolean(KEY_SBLOCCATO, false)
        fotoTotaliScattate = trialPrefs.getInt(KEY_FOTO_TOTALI, 0)

        findViewById<TextView>(R.id.tvNomeCartella).text = nomeCartella
        tvContatore = findViewById(R.id.tvContatore)
        tvZoom = findViewById(R.id.tvZoom)
        btnTorcia = findViewById(R.id.btnTorcia)
        frameMiniatura = findViewById(R.id.frameMiniatura)
        ivMiniatura = findViewById(R.id.ivMiniatura)
        btnVideo = findViewById(R.id.btnVideo)
        btnFoto = findViewById(R.id.btnFoto)
        btnScatta = findViewById(R.id.btnScatta)
        viewFlashFoto = findViewById(R.id.viewFlashFoto)
        // AppCompat applica normalmente un tint automatico al background dei Button: senza toglierlo,
        // il rosso del pulsante durante la registrazione video risulterebbe smorzato/non visibile
        btnScatta.backgroundTintList = null

        contatore = contaElementiEsistenti()
        aggiornaTestoContatore()
        precaricaMiniaturaEsistente()

        avviaAnteprimaFotocamera()
        impostaModalita(video = false)

        btnScatta.setOnClickListener {
            if (modalitaVideo) alternaRegistrazioneVideo() else scattaFoto()
        }
        btnTorcia.setOnClickListener { attivaDisattivaTorcia() }
        frameMiniatura.setOnClickListener { apriUltimoElementoASchermoIntero() }
        btnFoto.setOnClickListener { impostaModalita(video = false) }
        btnVideo.setOnClickListener { impostaModalita(video = true) }
    }

    /** Cambia la modalità attiva (Foto o Video) evidenziando il tab corrispondente. Non si può cambiare durante una registrazione. */
    private fun impostaModalita(video: Boolean) {
        if (registrazioneInCorso != null) return

        modalitaVideo = video
        if (video) {
            btnVideo.background = ContextCompat.getDrawable(this, R.drawable.bg_video_pill_attivo)
            btnVideo.setTextColor(0xFFFFFFFF.toInt())
            btnVideo.setTypeface(null, android.graphics.Typeface.BOLD)

            btnFoto.background = ContextCompat.getDrawable(this, R.drawable.bg_pill_trasparente)
            btnFoto.setTextColor(0x80FFFFFF.toInt())
            btnFoto.setTypeface(null, android.graphics.Typeface.NORMAL)
        } else {
            btnFoto.background = ContextCompat.getDrawable(this, R.drawable.bg_video_pill_attivo)
            btnFoto.setTextColor(0xFFFFFFFF.toInt())
            btnFoto.setTypeface(null, android.graphics.Typeface.BOLD)

            btnVideo.background = ContextCompat.getDrawable(this, R.drawable.bg_pill_trasparente)
            btnVideo.setTextColor(0x80FFFFFF.toInt())
            btnVideo.setTypeface(null, android.graphics.Typeface.NORMAL)
            // In modalità Foto il flash non deve restare acceso: CameraX lo accenderà da solo, solo al momento dello scatto
            if (::imageCapture.isInitialized) {
                imageCapture.flashMode = if (flashSelezionato) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
            }
            camera?.cameraControl?.enableTorch(false)
        }
    }

    private fun avviaAnteprimaFotocamera() {
        val previewView = findViewById<PreviewView>(R.id.previewView)
        previewView.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            true
        }

        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setTargetRotation(Surface.ROTATION_0)
                .setFlashMode(if (flashSelezionato) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF)
                .build()

            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(Quality.HD))
                .build()
            videoCapture = VideoCapture.withOutput(recorder)

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                camera = cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageCapture, videoCapture
                )
                camera?.cameraInfo?.zoomState?.observe(this) { zoomState ->
                    tvZoom.text = String.format(Locale.ITALY, "%.1fx", zoomState.zoomRatio)
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Errore avvio fotocamera: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /**
     * Seleziona/deseleziona il flash. Non lo accende subito:
     * - in modalità Foto si accenderà da solo, solo per l'istante dello scatto (gestito da CameraX)
     * - in modalità Video resta spento finché non parte la registrazione, poi resta acceso per tutta la sua durata
     * (l'unica eccezione è se si preme il pulsante mentre una registrazione è già in corso: in quel caso la torcia si accende/spegne subito)
     */
    private fun attivaDisattivaTorcia() {
        val cam = camera ?: return
        if (!cam.cameraInfo.hasFlashUnit()) {
            Toast.makeText(this, "Questo dispositivo non ha una torcia", Toast.LENGTH_SHORT).show()
            return
        }
        flashSelezionato = !flashSelezionato
        btnTorcia.text = if (flashSelezionato) "⚡ ON" else "⚡"

        if (::imageCapture.isInitialized) {
            imageCapture.flashMode = if (flashSelezionato) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        }

        if (registrazioneInCorso != null) {
            cam.cameraControl.enableTorch(flashSelezionato)
        }
    }

    private fun scattaFoto() {
        if (registrazioneInCorso != null) return

        if (!appSbloccata && fotoTotaliScattate >= LIMITE_FOTO_PROVA) {
            mostraDialogSblocco()
            return
        }

        val prossimoNumero = contatore + 1
        val nomeFile = "$nomeCartella $prossimoNumero"

        var fileLegacyTemp: File? = null

        val outputOptions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            creaOutputOptionsMediaStore(nomeFile)
        } else {
            val file = costruisciFileLegacyFoto(nomeFile)
            fileLegacyTemp = file
            ImageCapture.OutputFileOptions.Builder(file).build()
        }

        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    contatore = prossimoNumero
                    aggiornaTestoContatore()

                    ultimoUri = output.savedUri
                    ultimoFile = fileLegacyTemp
                    ultimoNomeFile = nomeFile
                    ultimoEraVideo = false
                    mostraMiniaturaFoto(ultimoUri, ultimoFile)
                    eseguiEffettoFlashScatto()

                    registraElementoVersoLimiteProva(nomeFile)
                }

                override fun onError(exc: ImageCaptureException) {
                    Toast.makeText(
                        this@CameraActivity,
                        "Errore salvataggio foto: ${exc.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        )
    }

    /** Avvia o ferma la registrazione di un video (durata massima 40 secondi) */
    @SuppressLint("MissingPermission")
    private fun alternaRegistrazioneVideo() {
        val registrazioneAttiva = registrazioneInCorso
        if (registrazioneAttiva != null) {
            registrazioneAttiva.stop()
            return
        }

        if (!appSbloccata && fotoTotaliScattate >= LIMITE_FOTO_PROVA) {
            mostraDialogSblocco()
            return
        }

        if (PermissionChecker.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO)
            != PermissionChecker.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Serve il permesso microfono per registrare i video", Toast.LENGTH_LONG).show()
            return
        }

        val videoCaptureAttuale = videoCapture ?: return
        val prossimoNumero = contatore + 1
        val nomeFile = "$nomeCartella $prossimoNumero"

        var fileLegacyTemp: File? = null

        val pendingRecording = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val outputOptions = creaOutputOptionsVideoMediaStore(nomeFile)
            videoCaptureAttuale.output.prepareRecording(this, outputOptions)
        } else {
            val file = costruisciFileLegacyVideo(nomeFile)
            fileLegacyTemp = file
            val outputOptions = FileOutputOptions.Builder(file).build()
            videoCaptureAttuale.output.prepareRecording(this, outputOptions)
        }.withAudioEnabled()

        registrazioneInCorso = pendingRecording.start(ContextCompat.getMainExecutor(this)) { evento ->
            when (evento) {
                is VideoRecordEvent.Start -> {
                    contatore = prossimoNumero
                    aggiornaTestoContatore()
                    avviaTimerRegistrazione()
                    btnVideo.isEnabled = false
                    btnFoto.isEnabled = false
                    btnScatta.background = ContextCompat.getDrawable(this, R.drawable.bg_shutter_button_rec)
                    // In video il flash, se selezionato, resta acceso per tutta la durata della registrazione
                    if (flashSelezionato) {
                        camera?.cameraControl?.enableTorch(true)
                    }
                }
                is VideoRecordEvent.Finalize -> {
                    fermaTimerRegistrazione()
                    btnVideo.isEnabled = true
                    btnFoto.isEnabled = true
                    btnScatta.background = ContextCompat.getDrawable(this, R.drawable.bg_shutter_button)
                    camera?.cameraControl?.enableTorch(false)
                    registrazioneInCorso = null

                    if (!evento.hasError()) {
                        ultimoUri = evento.outputResults.outputUri
                        ultimoFile = fileLegacyTemp
                        ultimoNomeFile = nomeFile
                        ultimoEraVideo = true
                        mostraMiniaturaVideo(ultimoUri, ultimoFile)
                        registraElementoVersoLimiteProva(nomeFile)
                    } else {
                        Toast.makeText(
                            this,
                            "Errore durante la registrazione del video (codice ${evento.error})",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
                else -> Unit
            }
        }

        // Ferma automaticamente la registrazione dopo 40 secondi
        handlerTimer.postDelayed({
            registrazioneInCorso?.stop()
        }, DURATA_MASSIMA_VIDEO_MS)
    }

    private fun avviaTimerRegistrazione() {
        secondiRimanenti = 40
        aggiornaTestoTimer()
        handlerTimer.removeCallbacks(runnableTimer)
        handlerTimer.postDelayed(runnableTimer, 1000)
    }

    private fun fermaTimerRegistrazione() {
        handlerTimer.removeCallbacks(runnableTimer)
        btnScatta.text = ""
    }

    /** Mostra il conteggio alla rovescia dei secondi rimanenti direttamente nel pulsante di scatto, che durante il video diventa rosso */
    private fun aggiornaTestoTimer() {
        val secondi = secondiRimanenti.coerceAtLeast(0)
        btnScatta.text = String.format(Locale.ITALY, "%d", secondi)
    }

    /** Aggiorna il conteggio della versione di prova (foto E video condividono lo stesso limite) */
    private fun registraElementoVersoLimiteProva(nomeFile: String) {
        if (!appSbloccata) {
            fotoTotaliScattate += 1
            trialPrefs.edit().putInt(KEY_FOTO_TOTALI, fotoTotaliScattate).apply()

            val rimanenti = LIMITE_FOTO_PROVA - fotoTotaliScattate
            if (rimanenti > 0) {
                Toast.makeText(
                    this,
                    "Salvato: $nomeFile — elementi della versione trial rimasti: $rimanenti",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                Toast.makeText(
                    this,
                    "Salvato: $nomeFile — hai raggiunto il limite della versione trial",
                    Toast.LENGTH_LONG
                ).show()
            }
        } else {
            Toast.makeText(this, "Salvato: $nomeFile", Toast.LENGTH_SHORT).show()
        }
    }

    /** Android 10+ (API 29+): salva la foto tramite MediaStore, visibile subito in Galleria */
    private fun creaOutputOptionsMediaStore(nomeFile: String): ImageCapture.OutputFileOptions {
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, nomeFile)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella"
            )
        }
        return ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        ).build()
    }

    /** Android 10+ (API 29+): salva il video tramite MediaStore, visibile subito in Galleria */
    private fun creaOutputOptionsVideoMediaStore(nomeFile: String): MediaStoreOutputOptions {
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, nomeFile)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                "${Environment.DIRECTORY_MOVIES}/$SOTTOCARTELLA/$nomeCartella"
            )
        }
        return MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(contentValues)
            .build()
    }

    /** Android 9 e precedenti: scrive la foto direttamente nella cartella pubblica Pictures */
    private fun costruisciFileLegacyFoto(nomeFile: String): File {
        val cartellaPubblica = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            "$SOTTOCARTELLA/$nomeCartella"
        )
        if (!cartellaPubblica.exists()) {
            cartellaPubblica.mkdirs()
        }
        return File(cartellaPubblica, "$nomeFile.jpg")
    }

    /** Android 9 e precedenti: scrive il video direttamente nella cartella pubblica Movies */
    private fun costruisciFileLegacyVideo(nomeFile: String): File {
        val cartellaPubblica = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
            "$SOTTOCARTELLA/$nomeCartella"
        )
        if (!cartellaPubblica.exists()) {
            cartellaPubblica.mkdirs()
        }
        return File(cartellaPubblica, "$nomeFile.mp4")
    }

    /** Mostra un dialog che chiede il codice per sbloccare l'app oltre il limite di prova */
    private fun mostraDialogSblocco() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            hint = "Inserisci il codice"
        }

        AlertDialog.Builder(this)
            .setTitle("Versione trial terminata")
            .setMessage("Hai raggiunto il limite di $LIMITE_FOTO_PROVA elementi gratuiti (foto o video). Inserisci il codice per continuare a usare l'app.")
            .setView(input)
            .setPositiveButton("Sblocca") { _, _ ->
                val codiceInserito = input.text.toString().trim()
                if (codiceInserito.equals(CODICE_SBLOCCO, ignoreCase = false)) {
                    appSbloccata = true
                    trialPrefs.edit().putBoolean(KEY_SBLOCCATO, true).apply()
                    Toast.makeText(this, "App sbloccata, buon lavoro!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Codice errato", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Annulla", null)
            .setCancelable(false)
            .show()
    }

    /** Mostra un breve lampo bianco a schermo intero, come feedback visivo che la foto è stata scattata */
    private fun eseguiEffettoFlashScatto() {
        viewFlashFoto.visibility = View.VISIBLE
        viewFlashFoto.postDelayed({ viewFlashFoto.visibility = View.GONE }, 120)
    }

    /** Carica una miniatura ridotta della foto appena scattata, in background */
    private fun mostraMiniaturaFoto(uri: Uri?, file: File?) {
        Thread {
            val bitmap = ImmagineUtils.caricaBitmapCorretto(this, uri, file, inSampleSize = 4)

            runOnUiThread {
                if (bitmap != null) {
                    ivMiniatura.setImageBitmap(bitmap)
                    frameMiniatura.visibility = View.VISIBLE
                }
            }
        }.start()
    }

    /** Carica un fotogramma del video appena registrato come miniatura, in background */
    private fun mostraMiniaturaVideo(uri: Uri?, file: File?) {
        Thread {
            val bitmap = try {
                val retriever = android.media.MediaMetadataRetriever()
                if (uri != null) {
                    retriever.setDataSource(this, uri)
                } else if (file != null) {
                    retriever.setDataSource(file.absolutePath)
                }
                val frame = retriever.getFrameAtTime(0)
                retriever.release()
                frame
            } catch (e: Exception) {
                null
            }

            runOnUiThread {
                if (bitmap != null) {
                    ivMiniatura.setImageBitmap(bitmap)
                    frameMiniatura.visibility = View.VISIBLE
                }
            }
        }.start()
    }

    /** Carica in background la miniatura dell'ultimo elemento (foto o video) già presente nella cartella, anche se non scattato in questa sessione */
    private fun precaricaMiniaturaEsistente() {
        Thread {
            val ultimo = elencoElementiCartella().lastOrNull() ?: return@Thread
            runOnUiThread {
                ultimoUri = ultimo.uri
                ultimoFile = ultimo.file
                ultimoNomeFile = ultimo.nomeVisualizzato.substringBeforeLast(".")
                ultimoEraVideo = ultimo.isVideo
                if (ultimo.isVideo) {
                    mostraMiniaturaVideo(ultimo.uri, ultimo.file)
                } else {
                    mostraMiniaturaFoto(ultimo.uri, ultimo.file)
                }
            }
        }.start()
    }

    /** Apre l'intera galleria della cartella a schermo intero, partendo dall'ultimo elemento, così si può scorrere avanti e indietro tra tutte le foto/video */
    private fun apriUltimoElementoASchermoIntero() {
        if (ultimoUri == null && ultimoFile == null) return

        Thread {
            val elenco = elencoElementiCartella()
            if (elenco.isEmpty()) return@Thread

            runOnUiThread {
                GalleriaCorrente.elementi = elenco
                val intent = Intent(this, FullImageActivity::class.java)
                intent.putExtra(FullImageActivity.EXTRA_INDICE, elenco.size - 1)
                startActivityForResult(intent, REQUEST_CODE_VISUALIZZA_ELEMENTO)
            }
        }.start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_VISUALIZZA_ELEMENTO
            && resultCode == RESULT_OK
            && data?.getBooleanExtra(FullImageActivity.EXTRA_ELIMINATO, false) == true
        ) {
            // L'eliminazione può ora riguardare un elemento qualsiasi (non più solo l'ultimo, essendo possibile scorrere tutta la galleria):
            // rileggiamo lo stato reale della cartella invece di limitarci a decrementare il contatore
            aggiornaDopoEliminazione()
        }
    }

    /** Ricalcola contatore e miniatura leggendo di nuovo il contenuto reale della cartella, dopo l'eliminazione di un elemento */
    private fun aggiornaDopoEliminazione() {
        Thread {
            val elenco = elencoElementiCartella()
            val nuovoContatore = elenco.maxOfOrNull { it.numero } ?: 0
            val ultimo = elenco.lastOrNull()

            runOnUiThread {
                contatore = nuovoContatore
                aggiornaTestoContatore()

                if (ultimo != null) {
                    ultimoUri = ultimo.uri
                    ultimoFile = ultimo.file
                    ultimoNomeFile = ultimo.nomeVisualizzato.substringBeforeLast(".")
                    ultimoEraVideo = ultimo.isVideo
                    if (ultimo.isVideo) mostraMiniaturaVideo(ultimo.uri, ultimo.file)
                    else mostraMiniaturaFoto(ultimo.uri, ultimo.file)
                } else {
                    ivMiniatura.setImageDrawable(null)
                    frameMiniatura.visibility = View.GONE
                    ultimoUri = null
                    ultimoFile = null
                    ultimoNomeFile = ""
                }
            }
        }.start()
    }

    /**
     * Conta quante foto E video esistono già per questo nome di sopralluogo,
     * cosi se l'utente chiude e riapre l'app la numerazione prosegue
     * (es. Castano 1, Castano 2 ... invece di ripartire da 1), che siano foto o video.
     */
    private fun contaElementiEsistenti(): Int {
        var massimo = 0
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                massimo = max(massimo, massimoNumeroInMediaStore(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella/"
                ))
                massimo = max(massimo, massimoNumeroInMediaStore(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    "${Environment.DIRECTORY_MOVIES}/$SOTTOCARTELLA/$nomeCartella/"
                ))
            } else {
                val cartellaFoto = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "$SOTTOCARTELLA/$nomeCartella"
                )
                cartellaFoto.listFiles()?.forEach { file ->
                    estraiNumero(file.name)?.let { if (it > massimo) massimo = it }
                }
                val cartellaVideo = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    "$SOTTOCARTELLA/$nomeCartella"
                )
                cartellaVideo.listFiles()?.forEach { file ->
                    estraiNumero(file.name)?.let { if (it > massimo) massimo = it }
                }
            }
        } catch (e: Exception) {
            // Se la query fallisce, si riparte semplicemente da 1
        }
        return massimo
    }

    /** Restituisce tutti gli elementi (foto e video) già presenti nella cartella di questo sopralluogo, in ordine crescente di numero */
    private fun elencoElementiCartella(): List<FotoItem> {
        val lista = mutableListOf<FotoItem>()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                aggiungiElementiDaMediaStore(
                    lista,
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella/",
                    isVideo = false
                )
                aggiungiElementiDaMediaStore(
                    lista,
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    "${Environment.DIRECTORY_MOVIES}/$SOTTOCARTELLA/$nomeCartella/",
                    isVideo = true
                )
            } else {
                val cartellaFoto = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "$SOTTOCARTELLA/$nomeCartella"
                )
                cartellaFoto.listFiles()?.forEach { file ->
                    estraiNumero(file.name)?.let { lista.add(FotoItem(null, file, it, file.name, isVideo = false)) }
                }
                val cartellaVideo = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    "$SOTTOCARTELLA/$nomeCartella"
                )
                cartellaVideo.listFiles()?.forEach { file ->
                    estraiNumero(file.name)?.let { lista.add(FotoItem(null, file, it, file.name, isVideo = true)) }
                }
            }
        } catch (e: Exception) {
            // lista resta vuota o parziale
        }
        lista.sortBy { it.numero }
        return lista
    }

    private fun aggiungiElementiDaMediaStore(
        lista: MutableList<FotoItem>,
        collectionUri: Uri,
        relativePath: String,
        isVideo: Boolean
    ) {
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
        val selectionArgs = arrayOf(relativePath)
        contentResolver.query(collectionUri, projection, selection, selectionArgs, null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val displayName = cursor.getString(nameCol)
                val numero = estraiNumero(displayName) ?: continue
                val uri = Uri.withAppendedPath(collectionUri, id.toString())
                lista.add(FotoItem(uri, null, numero, displayName, isVideo))
            }
        }
    }

    private fun massimoNumeroInMediaStore(collectionUri: Uri, relativePath: String): Int {
        var massimo = 0
        val projection = arrayOf(MediaStore.MediaColumns.DISPLAY_NAME)
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
        val selectionArgs = arrayOf(relativePath)
        contentResolver.query(collectionUri, projection, selection, selectionArgs, null)?.use { cursor ->
            val colonnaNome = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val nomeCompleto = cursor.getString(colonnaNome)
                estraiNumero(nomeCompleto)?.let { if (it > massimo) massimo = it }
            }
        }
        return massimo
    }

    private fun max(a: Int, b: Int) = if (a > b) a else b

    /**
     * Estrae il numero progressivo dal nome del file (es. "Castano 4.jpg" -> 4).
     * Non è sensibile a maiuscole/minuscole o spazi extra, e ignora eventuali suffissi
     * come "(1)" che Android aggiunge da solo se esiste già un file con lo stesso nome:
     * un confronto troppo rigido faceva sparire del tutto l'elemento dall'elenco
     * (numerazione a 0 in galleria, miniatura della fotocamera che non si apriva).
     */
    private fun estraiNumero(nomeFile: String): Int? {
        val senzaEstensione = nomeFile.substringBeforeLast(".").trim()
        val regex = Regex("^${Regex.escape(nomeCartella.trim())}\\s+(\\d+)", RegexOption.IGNORE_CASE)
        return regex.find(senzaEstensione)?.groupValues?.get(1)?.toIntOrNull()
    }

    private fun aggiornaTestoContatore() {
        tvContatore.text = "Elementi: $contatore"
    }

    override fun onDestroy() {
        super.onDestroy()
        registrazioneInCorso?.stop()
        handlerTimer.removeCallbacksAndMessages(null)
    }
}
