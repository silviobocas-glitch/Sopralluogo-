package com.example.sopralluoghi

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** Salva l'elenco dei sopralluoghi creati (nomi cartella) nelle SharedPreferences */
object PrefsHelper {
    private const val PREFS = "sopralluoghi_prefs"
    private const val KEY_LISTA = "lista_nomi"
    private const val SEPARATORE = "\u0001"

    fun getLista(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LISTA, "") ?: ""
        return if (raw.isEmpty()) emptyList() else raw.split(SEPARATORE)
    }

    /** Aggiunge il nome in cima alla lista (più recente prima). Se esiste già, lo sposta in cima. */
    fun aggiungiOSpostaInCima(context: Context, nome: String) {
        val lista = getLista(context).toMutableList()
        lista.remove(nome)
        lista.add(0, nome)
        salvaLista(context, lista)
    }

    fun rimuovi(context: Context, nome: String) {
        val lista = getLista(context).toMutableList()
        lista.remove(nome)
        salvaLista(context, lista)
    }

    private fun salvaLista(context: Context, lista: List<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_LISTA, lista.joinToString(SEPARATORE))
            .apply()
    }
}

/** Elimina definitivamente foto, video, note e riferimenti di un sopralluogo */
object GestioneCartelle {
    private const val SOTTOCARTELLA = "Sopralluoghi"

    fun eliminaTutto(context: Context, nomeCartella: String) {
        eliminaFoto(context, nomeCartella)
        eliminaVideo(context, nomeCartella)
        eliminaNote(context, nomeCartella)
    }

    private fun eliminaFoto(context: Context, nomeCartella: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val relativePath = "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella/"
                context.contentResolver.delete(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    "${MediaStore.MediaColumns.RELATIVE_PATH} = ?",
                    arrayOf(relativePath)
                )
            } else {
                File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "$SOTTOCARTELLA/$nomeCartella"
                ).deleteRecursively()
            }
        } catch (e: Exception) {
            // proseguiamo comunque con le altre eliminazioni
        }
    }

    /** In precedenza qui i video non venivano eliminati: restavano orfani nella cartella Movies */
    private fun eliminaVideo(context: Context, nomeCartella: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val relativePath = "${Environment.DIRECTORY_MOVIES}/$SOTTOCARTELLA/$nomeCartella/"
                context.contentResolver.delete(
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    "${MediaStore.MediaColumns.RELATIVE_PATH} = ?",
                    arrayOf(relativePath)
                )
            } else {
                File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                    "$SOTTOCARTELLA/$nomeCartella"
                ).deleteRecursively()
            }
        } catch (e: Exception) {
            // proseguiamo comunque con le altre eliminazioni
        }
    }

    private fun eliminaNote(context: Context, nomeCartella: String) {
        // Le note sono archiviate nella cartella di sistema Documents
        try {
            File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
                "$SOTTOCARTELLA/$nomeCartella"
            ).deleteRecursively()
        } catch (e: Exception) {
            // ignorato
        }
        // Ripulisce anche eventuali note salvate da versioni precedenti dell'app (storage interno)
        try {
            File(context.filesDir, "$SOTTOCARTELLA/$nomeCartella").deleteRecursively()
        } catch (e: Exception) {
            // ignorato
        }
    }
}
