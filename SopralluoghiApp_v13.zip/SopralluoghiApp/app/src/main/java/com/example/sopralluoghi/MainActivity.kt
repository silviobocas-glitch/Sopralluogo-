package com.example.sopralluoghi

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private val elenco = mutableListOf<String>()
    private lateinit var adapter: FolderAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (!VerificaFirma.firmaValida(this)) {
            AlertDialog.Builder(this)
                .setTitle("App non originale")
                .setMessage("Questa copia dell'app è stata modificata e non può essere utilizzata.")
                .setCancelable(false)
                .setPositiveButton("Chiudi") { _, _ -> finish() }
                .show()
            return
        }

        val rv = findViewById<RecyclerView>(R.id.rvCartelle)
        val layoutManager = GridLayoutManager(this, 2)
        layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                return if (position == 0) 2 else 1
            }
        }
        rv.layoutManager = layoutManager
        adapter = FolderAdapter(
            elenco,
            onNuovo = { mostraDialogNuovoSopralluogo() },
            onApri = { nome -> apriCartella(nome) },
            onLongClick = { nome -> mostraMenuCartella(nome) }
        )
        rv.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        elenco.clear()
        elenco.addAll(PrefsHelper.getLista(this))
        adapter.notifyDataSetChanged()
    }

    private fun mostraDialogNuovoSopralluogo() {
        val vistaDialog = layoutInflater.inflate(R.layout.dialog_nuovo_sopralluogo, null)
        val campoNome = vistaDialog.findViewById<TextInputEditText>(R.id.etNomeSopralluogo)

        val dialog = AlertDialog.Builder(this)
            .setView(vistaDialog)
            .create()

        vistaDialog.findViewById<android.view.View>(R.id.btnAnnullaDialog).setOnClickListener {
            dialog.dismiss()
        }

        vistaDialog.findViewById<android.view.View>(R.id.btnCreaDialog).setOnClickListener {
            val nomeGrezzo = campoNome.text.toString().trim()
            if (nomeGrezzo.isNotEmpty()) {
                val nome = nomeGrezzo.replace(Regex("[\\\\/:*?\"<>|]"), "")
                PrefsHelper.aggiungiOSpostaInCima(this, nome)
                dialog.dismiss()
                apriCartella(nome)
            } else {
                Toast.makeText(this, "Inserisci un nome", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    private fun apriCartella(nome: String) {
        val intent = Intent(this, FolderActivity::class.java)
        intent.putExtra(FolderActivity.EXTRA_NOME, nome)
        startActivity(intent)
    }

    private fun mostraMenuCartella(nome: String) {
        val opzioni = arrayOf("Apri", "Condividi (zip)", "Elimina cartella")
        AlertDialog.Builder(this)
            .setTitle(nome)
            .setItems(opzioni) { _, which ->
                when (which) {
                    0 -> apriCartella(nome)
                    1 -> condividiCartella(nome)
                    2 -> confermaEliminazione(nome)
                }
            }
            .show()
    }

    private fun condividiCartella(nome: String) {
        Toast.makeText(this, "Preparo il file da condividere...", Toast.LENGTH_SHORT).show()
        Thread {
            val zipFile = ZipHelper.creaZipDiCartella(this, nome)
            runOnUiThread {
                if (zipFile != null) {
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", zipFile)
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/zip"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(shareIntent, "Condividi $nome"))
                } else {
                    Toast.makeText(this, "Errore nella creazione dello zip", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun confermaEliminazione(nome: String) {
        AlertDialog.Builder(this)
            .setTitle("Eliminare \"$nome\"?")
            .setMessage("Verranno eliminate anche tutte le foto e le note di questo sopralluogo. L'operazione non è reversibile.")
            .setPositiveButton("Elimina") { _, _ -> eliminaCartella(nome) }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun eliminaCartella(nome: String) {
        Thread {
            GestioneCartelle.eliminaTutto(this, nome)
            PrefsHelper.rimuovi(this, nome)
            runOnUiThread {
                elenco.clear()
                elenco.addAll(PrefsHelper.getLista(this))
                adapter.notifyDataSetChanged()
                Toast.makeText(this, "\"$nome\" eliminato", Toast.LENGTH_SHORT).show()
            }
        }.start()
    }
}
