package com.example.sopralluoghi

import android.content.Context
import java.io.File

/**
 * Le note vivono ora nella STESSA cartella privata dell'app di foto e video
 * (Android/data/<package>/files/Sopralluoghi/<nome>/note.txt — vedi StorageHelper), invece
 * che nella cartella di sistema Documents. In questo modo tutto il materiale di un
 * sopralluogo (foto, video e nota) sta in un unico posto e viene eliminato insieme, sia
 * cancellando il sopralluogo dall'app sia disinstallando l'app.
 */
object NotesHelper {
    private const val NOME_FILE = "note.txt"

    private fun fileNota(context: Context, nomeCartella: String): File =
        File(StorageHelper.cartellaSopralluogo(context, nomeCartella), NOME_FILE)

    fun leggiNota(context: Context, nomeCartella: String): String {
        return try {
            val file = fileNota(context, nomeCartella)
            if (file.exists()) file.readText() else ""
        } catch (e: Exception) {
            ""
        }
    }

    fun salvaNota(context: Context, nomeCartella: String, testo: String) {
        try {
            fileNota(context, nomeCartella).writeText(testo)
        } catch (e: Exception) {
            // se il salvataggio fallisce non blocchiamo l'uscita dalla schermata
        }
    }

    /** Elimina la nota di un sopralluogo. Non è più strettamente necessaria come chiamata
     * separata (StorageHelper.eliminaCartellaSopralluogo cancella già tutta la cartella,
     * nota inclusa), ma resta utile da poter richiamare singolarmente. */
    fun eliminaNota(context: Context, nomeCartella: String) {
        try {
            fileNota(context, nomeCartella).delete()
        } catch (e: Exception) {
            // ignorato
        }
    }
}
