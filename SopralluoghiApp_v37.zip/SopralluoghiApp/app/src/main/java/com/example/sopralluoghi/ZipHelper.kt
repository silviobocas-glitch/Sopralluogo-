package com.example.sopralluoghi

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ZipHelper {
    private const val SOTTOCARTELLA = "Sopralluoghi"

    /** Crea uno zip (in cache) con tutte le foto e la nota del sopralluogo. Ritorna null in caso di errore. */
    fun creaZipDiCartella(context: Context, nomeCartella: String): File? {
        return try {
            val zipFile = File(context.cacheDir, "$nomeCartella.zip")
            if (zipFile.exists()) zipFile.delete()

            ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
                aggiungiFotoAllozip(context, nomeCartella, zos)
                aggiungiVideoAllozip(context, nomeCartella, zos)
                aggiungiNotaAllozip(context, nomeCartella, zos)
            }
            zipFile
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Copia uno zip già creato (in cache) nella posizione scelta dall'utente tramite il
     * selettore di sistema (Storage Access Framework). È l'utente stesso a decidere cartella
     * e nome file nella schermata di sistema, quindi qui basta scrivere i byte nell'Uri
     * restituito. Ritorna true se la scrittura è andata a buon fine.
     */
    fun scriviZipSuUri(context: Context, zipFile: File, uriDestinazione: Uri): Boolean {
        return try {
            context.contentResolver.openOutputStream(uriDestinazione)?.use { output ->
                FileInputStream(zipFile).use { input -> input.copyTo(output) }
            } ?: return false
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun aggiungiFotoAllozip(context: Context, nomeCartella: String, zos: ZipOutputStream) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella/"
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                arrayOf(relativePath),
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.getString(nameCol)
                    val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                    try {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            zos.putNextEntry(ZipEntry(displayName))
                            input.copyTo(zos)
                            zos.closeEntry()
                        }
                    } catch (e: Exception) {
                        // salta questa foto e continua con le altre
                    }
                }
            }
        } else {
            val cartellaPubblica = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "$SOTTOCARTELLA/$nomeCartella"
            )
            cartellaPubblica.listFiles()?.forEach { file ->
                try {
                    FileInputStream(file).use { input ->
                        zos.putNextEntry(ZipEntry(file.name))
                        input.copyTo(zos)
                        zos.closeEntry()
                    }
                } catch (e: Exception) {
                    // salta questo file
                }
            }
        }
    }

    private fun aggiungiVideoAllozip(context: Context, nomeCartella: String, zos: ZipOutputStream) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_MOVIES}/$SOTTOCARTELLA/$nomeCartella/"
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                arrayOf(relativePath),
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.getString(nameCol)
                    val uri = Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString())
                    try {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            zos.putNextEntry(ZipEntry(displayName))
                            input.copyTo(zos)
                            zos.closeEntry()
                        }
                    } catch (e: Exception) {
                        // salta questo video e continua con gli altri
                    }
                }
            }
        } else {
            val cartellaPubblica = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "$SOTTOCARTELLA/$nomeCartella"
            )
            cartellaPubblica.listFiles()?.forEach { file ->
                try {
                    FileInputStream(file).use { input ->
                        zos.putNextEntry(ZipEntry(file.name))
                        input.copyTo(zos)
                        zos.closeEntry()
                    }
                } catch (e: Exception) {
                    // salta questo file
                }
            }
        }
    }

    private fun aggiungiNotaAllozip(context: Context, nomeCartella: String, zos: ZipOutputStream) {
        val noteFile = File(context.filesDir, "$SOTTOCARTELLA/$nomeCartella/note.txt")
        if (noteFile.exists()) {
            try {
                FileInputStream(noteFile).use { input ->
                    zos.putNextEntry(ZipEntry("$nomeCartella.txt"))
                    input.copyTo(zos)
                    zos.closeEntry()
                }
            } catch (e: Exception) {
                // ignorato
            }
        }
    }
}
