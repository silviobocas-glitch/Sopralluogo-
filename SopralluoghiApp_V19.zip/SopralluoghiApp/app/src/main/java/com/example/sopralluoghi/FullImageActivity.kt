package com.example.sopralluoghi

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.MediaController
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

class FullImageActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "EXTRA_URI"
        const val EXTRA_FILE_PATH = "EXTRA_FILE_PATH"
        const val EXTRA_NOME = "EXTRA_NOME"
        const val EXTRA_IS_VIDEO = "EXTRA_IS_VIDEO"
        const val EXTRA_ELIMINATO = "EXTRA_ELIMINATO"
    }

    private var uri: Uri? = null
    private var filePath: String? = null
    private var isVideo: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_full_image)

        uri = intent.getParcelableExtra(EXTRA_URI)
        filePath = intent.getStringExtra(EXTRA_FILE_PATH)
        isVideo = intent.getBooleanExtra(EXTRA_IS_VIDEO, false)
        val nome = intent.getStringExtra(EXTRA_NOME) ?: ""

        val iv = findViewById<ZoomableImageView>(R.id.ivFotoIntera)
        val videoView = findViewById<VideoView>(R.id.videoIntero)
        findViewById<TextView>(R.id.btnIndietroFull).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnEliminaFoto).setOnClickListener { confermaEliminazione(nome) }

        if (isVideo) {
            iv.visibility = View.GONE
            videoView.visibility = View.VISIBLE
            avviaRiproduzioneVideo(videoView)
        } else {
            Thread {
                val filePathObj = filePath?.let { File(it) }
                val bitmap = ImmagineUtils.caricaBitmapCorretto(this, uri, filePathObj, inSampleSize = 1)
                runOnUiThread {
                    if (bitmap != null) {
                        iv.impostaBitmapEResetZoom(bitmap)
                    } else {
                        Toast.makeText(this, "Impossibile aprire la foto", Toast.LENGTH_SHORT).show()
                    }
                }
            }.start()
        }
    }

    /** Riproduce il video con i controlli standard (play/pausa/avanzamento) */
    private fun avviaRiproduzioneVideo(videoView: VideoView) {
        val uriDaRiprodurre = uri ?: filePath?.let { path ->
            FileProvider.getUriForFile(this, "$packageName.fileprovider", File(path))
        }
        if (uriDaRiprodurre == null) {
            Toast.makeText(this, "Impossibile aprire il video", Toast.LENGTH_SHORT).show()
            return
        }
        val controller = MediaController(this)
        controller.setAnchorView(videoView)
        videoView.setMediaController(controller)
        videoView.setVideoURI(uriDaRiprodurre)
        videoView.setOnPreparedListener { videoView.start() }
        videoView.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "Impossibile riprodurre il video", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun confermaEliminazione(nome: String) {
        AlertDialog.Builder(this)
            .setTitle("Eliminare questo elemento?")
            .setMessage("$nome verrà eliminato definitivamente.")
            .setPositiveButton("Elimina") { _, _ -> eliminaFoto() }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun eliminaFoto() {
        try {
            if (uri != null) {
                contentResolver.delete(uri!!, null, null)
            } else if (filePath != null) {
                File(filePath!!).delete()
            }
            Toast.makeText(this, "Elemento eliminato", Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK, Intent().putExtra(EXTRA_ELIMINATO, true))
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Errore durante l'eliminazione: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
