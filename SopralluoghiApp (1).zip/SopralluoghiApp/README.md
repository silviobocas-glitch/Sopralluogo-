# Sopralluoghi — App Android

App semplice per i sopralluoghi:

1. Apri l'app, scrivi il nome del sopralluogo (es. "Castano") e premi **"Crea cartella e apri fotocamera"**.
2. Si apre la fotocamera: ogni volta che premi **"Scatta foto"** viene salvata una foto chiamata `Castano 1`, `Castano 2`, `Castano 3`... in progressione.
3. Le foto vengono salvate in **Galleria → Pictures/Sopralluoghi/Castano** (visibile anche da Google Foto / gestione file).
4. Se chiudi l'app e la riapri scrivendo di nuovo "Castano", la numerazione riparte da dove era arrivata (non sovrascrive le foto già fatte).
5. Premi **"Fine"** per tornare alla schermata iniziale e iniziare un nuovo sopralluogo con un altro nome.

## Funzioni extra (stile Folder Camera)

- **Zoom**: pizzica lo schermo con due dita (pinch-to-zoom) sulla fotocamera. Il livello di zoom è mostrato in alto a destra (es. "2.0x").
- **Torcia**: il pulsante ⚡ in alto a destra accende/spegne la torcia (se il telefono ne ha una).
- **Anteprima ultima foto**: dopo ogni scatto appare una miniatura in basso a sinistra. Toccando la ✕ in alto a destra della miniatura elimini l'ultima foto e la numerazione torna indietro di uno (la prossima foto riprende lo stesso numero).

## Come compilare l'APK SENZA installare nulla sul PC

Se non puoi installare Android Studio (es. PC aziendale), puoi far compilare l'app **gratis nel browser** usando GitHub:

1. Estrai lo zip sul PC con "Estrai tutto" di Windows (nessuna installazione richiesta).
2. Vai su **github.com** e crea un account gratuito (se non ne hai già uno).
3. Crea un nuovo repository (es. "sopralluoghi-app"), può essere privato.
4. Apri il repository → **Add file → Upload files** → trascina dentro TUTTO il contenuto della cartella `SopralluoghiApp` (le sottocartelle `app`, `.github`, i file `build.gradle`, `settings.gradle`, ecc. — non la cartella stessa, il suo contenuto) → **Commit changes**.
5. Vai sulla scheda **Actions** del repository: la compilazione parte da sola (ci mette 3-5 minuti). Quando è verde, cliccaci sopra.
6. In fondo alla pagina, sotto **Artifacts**, scarica `sopralluoghi-apk` (è uno zip che contiene `app-debug.apk`).
7. Copia `app-debug.apk` sul telefono (via cavo USB, email a te stesso, o Google Drive) e aprilo per installarlo. Il telefono chiederà di autorizzare "Installa da fonte sconosciuta" solo per quel file: è un'impostazione del telefono, non richiede nulla sul PC.

Questo metodo compila l'APK sui server di GitHub, non sul tuo PC: non serve installare Android Studio né altro.

## Come compilare con Android Studio (se puoi installare programmi)

1. Installa **Android Studio** (gratuito): https://developer.android.com/studio
2. Apri Android Studio → **Open** → seleziona la cartella `SopralluoghiApp` (questa cartella).
3. Al primo avvio, Android Studio scaricherà da solo il Gradle Wrapper e le dipendenze (serve una connessione internet la prima volta). Lascia fare il sync automatico.
4. Collega il telefono Android via USB con il **debug USB attivo** (Impostazioni → Opzioni sviluppatore → Debug USB), oppure usa un emulatore.
5. Premi il tasto verde **Run ▶** in alto: l'app verrà installata e avviata sul telefono.

## Requisiti

- Android 7.0 (API 24) o superiore.
- Permesso fotocamera (richiesto automaticamente al primo avvio).

## Personalizzazioni facili

- **Cartella principale**: nel file `CameraActivity.kt` puoi cambiare `SOTTOCARTELLA = "Sopralluoghi"` con un altro nome.
- **Formato nome foto**: nella funzione `scattaFoto()`, la riga `val nomeFile = "$nomeCartella $prossimoNumero"` genera nomi tipo "Castano 1". Puoi cambiarla, ad esempio in `"$nomeCartella-$prossimoNumero"` per ottenere "Castano-1".
- **Icona dell'app**: al momento usa l'icona di default di Android. Per metterne una tua, in Android Studio fai clic destro su `res` → **New → Image Asset** e segui la procedura guidata.
