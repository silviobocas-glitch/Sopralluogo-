package com.example.sopralluoghi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private var nomeSopralluogo: String = ""

    private val richiestaPermessi = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { risultati ->
        val tuttoOk = risultati.values.all { it }
        if (tuttoOk) {
            avviaFotocamera()
        } else {
            Toast.makeText(
                this,
                "Servono i permessi di fotocamera (e storage) per continuare",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etNome = findViewById<TextInputEditText>(R.id.etNome)
        val btnInizia = findViewById<Button>(R.id.btnInizia)

        btnInizia.setOnClickListener {
            val nome = etNome.text.toString().trim()
            if (nome.isEmpty()) {
                Toast.makeText(this, "Inserisci il nome del sopralluogo", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // Puliamo il nome da caratteri non ammessi nei nomi file
            nomeSopralluogo = nome.replace(Regex("[\\\\/:*?\"<>|]"), "")
            controllaPermessiEAvvia()
        }
    }

    private fun controllaPermessiEAvvia() {
        val permessiNecessari = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            permessiNecessari.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val mancanti = permessiNecessari.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (mancanti.isEmpty()) {
            avviaFotocamera()
        } else {
            richiestaPermessi.launch(mancanti.toTypedArray())
        }
    }

    private fun avviaFotocamera() {
        val intent = Intent(this, CameraActivity::class.java)
        intent.putExtra(CameraActivity.EXTRA_NOME_SOPRALLUOGO, nomeSopralluogo)
        startActivity(intent)
    }
}
