package com.example.sopralluoghi

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.InputStream

/** Decodifica una foto (da Uri o File) applicando la rotazione corretta letta dai metadati EXIF */
object ImmagineUtils {

    fun caricaBitmapCorretto(
        context: Context,
        uri: Uri?,
        file: File?,
        inSampleSize: Int = 1
    ): Bitmap? {
        return try {
            val opzioni = BitmapFactory.Options().apply { this.inSampleSize = inSampleSize }

            val bitmapGrezzo: Bitmap? = when {
                uri != null -> apriStream(context, uri) { BitmapFactory.decodeStream(it, null, opzioni) }
                file != null -> BitmapFactory.decodeFile(file.absolutePath, opzioni)
                else -> null
            } ?: return null

            val gradi = leggiGradiRotazione(context, uri, file)
            if (gradi == 0) bitmapGrezzo else ruotaBitmap(bitmapGrezzo, gradi)
        } catch (e: Exception) {
            null
        }
    }

    private fun apriStream(context: Context, uri: Uri, azione: (InputStream) -> Bitmap?): Bitmap? {
        return context.contentResolver.openInputStream(uri)?.use { azione(it) }
    }

    private fun leggiGradiRotazione(context: Context, uri: Uri?, file: File?): Int {
        return try {
            val exif = when {
                uri != null -> context.contentResolver.openInputStream(uri)?.use { ExifInterface(it) }
                file != null -> ExifInterface(file.absolutePath)
                else -> null
            } ?: return 0

            when (exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        } catch (e: Exception) {
            0
        }
    }

    private fun ruotaBitmap(bitmap: Bitmap, gradi: Int): Bitmap {
        val matrix = Matrix().apply { postRotate(gradi.toFloat()) }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }
}
