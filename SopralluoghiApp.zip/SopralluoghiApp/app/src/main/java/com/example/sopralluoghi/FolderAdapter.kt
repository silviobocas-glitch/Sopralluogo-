package com.example.sopralluoghi

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FolderAdapter(
    private val elenco: List<String>,
    private val onNuovo: () -> Unit,
    private val onApri: (String) -> Unit,
    private val onLongClick: (String) -> Unit
) : RecyclerView.Adapter<FolderAdapter.TileViewHolder>() {

    class TileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val root: View = itemView.findViewById(R.id.rootTile)
        val icona: TextView = itemView.findViewById(R.id.tvIconaCartella)
        val nome: TextView = itemView.findViewById(R.id.tvNomeCartella)
        val sottotitolo: TextView = itemView.findViewById(R.id.tvSottotitoloCartella)
    }

    override fun getItemCount(): Int = elenco.size + 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TileViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder_tile, parent, false)
        return TileViewHolder(view)
    }

    override fun onBindViewHolder(holder: TileViewHolder, position: Int) {
        if (position == 0) {
            // Prima cella: tratteggiata e trasparente, per creare un nuovo sopralluogo
            holder.root.setBackgroundResource(R.drawable.bg_new_folder)
            holder.icona.text = "➕"
            holder.nome.text = "Nuovo sopralluogo"
            holder.sottotitolo.text = "Tocca per iniziare"
            holder.itemView.setOnClickListener { onNuovo() }
            holder.itemView.setOnLongClickListener(null)
            holder.itemView.isLongClickable = false
        } else {
            val nome = elenco[position - 1]
            holder.root.setBackgroundResource(R.drawable.bg_folder)
            holder.icona.text = "📁"
            holder.nome.text = nome
            holder.sottotitolo.text = "Tocca per aprire"
            holder.itemView.setOnClickListener { onApri(nome) }
            holder.itemView.setOnLongClickListener {
                onLongClick(nome)
                true
            }
        }
    }
}
