package com.example.sopralluoghi

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.concurrent.Executors

/** Rappresenta una foto: puo' venire da MediaStore (Uri) o da file diretto (Android vecchi) */
data class FotoItem(
    val uri: Uri?,
    val file: File?,
    val numero: Int,
    val nomeVisualizzato: String
)

class GalleryActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NOME_CARTELLA = "NOME_CARTELLA"
        private const val SOTTOCARTELLA = "Sopralluoghi"
    }

    private lateinit var nomeCartella: String
    private val elencoFoto = mutableListOf<FotoItem>()
    private lateinit var adapter: PhotoAdapter
    private val executor = Executors.newFixedThreadPool(3)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        nomeCartella = intent.getStringExtra(EXTRA_NOME_CARTELLA) ?: ""

        findViewById<TextView>(R.id.tvTitoloGalleria).text = nomeCartella
        findViewById<TextView>(R.id.btnIndietro).setOnClickListener { finish() }

        val rv = findViewById<RecyclerView>(R.id.rvFoto)
        rv.layoutManager = GridLayoutManager(this, 3)
        adapter = PhotoAdapter(elencoFoto, executor) { fotoItem -> apriFotoIntera(fotoItem) }
        rv.adapter = adapter

        caricaFoto()
    }

    override fun onResume() {
        super.onResume()
        // Ricarica ogni volta che si torna qui (es. dopo aver eliminato una foto)
        caricaFoto()
    }

    private fun caricaFoto() {
        Thread {
            val lista = mutableListOf<FotoItem>()
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val relativePath = "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella/"
                    val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
                    val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
                    val selectionArgs = arrayOf(relativePath)
                    contentResolver.query(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        projection,
                        selection,
                        selectionArgs,
                        null
                    )?.use { cursor ->
                        val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                        val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                        while (cursor.moveToNext()) {
                            val id = cursor.getLong(idCol)
                            val displayName = cursor.getString(nameCol)
                            val numero = estraiNumero(displayName) ?: 0
                            val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                            lista.add(FotoItem(uri, null, numero, displayName))
                        }
                    }
                } else {
                    val cartellaPubblica = File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                        "$SOTTOCARTELLA/$nomeCartella"
                    )
                    cartellaPubblica.listFiles()?.forEach { file ->
                        val numero = estraiNumero(file.name) ?: 0
                        lista.add(FotoItem(null, file, numero, file.name))
                    }
                }
            } catch (e: Exception) {
                // lista resta vuota o parziale
            }

            lista.sortBy { it.numero }

            runOnUiThread {
                elencoFoto.clear()
                elencoFoto.addAll(lista)
                adapter.notifyDataSetChanged()
                findViewById<TextView>(R.id.tvNumeroFoto).text = "${lista.size} foto"
                findViewById<View>(R.id.tvNessunaFoto).visibility =
                    if (lista.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    private fun estraiNumero(nomeFile: String): Int? {
        val senzaEstensione = nomeFile.substringBeforeLast(".")
        val prefisso = "$nomeCartella "
        if (!senzaEstensione.startsWith(prefisso)) return null
        return senzaEstensione.removePrefix(prefisso).toIntOrNull()
    }

    private fun apriFotoIntera(fotoItem: FotoItem) {
        val intent = Intent(this, FullImageActivity::class.java)
        intent.putExtra(FullImageActivity.EXTRA_URI, fotoItem.uri)
        intent.putExtra(FullImageActivity.EXTRA_FILE_PATH, fotoItem.file?.absolutePath)
        intent.putExtra(FullImageActivity.EXTRA_NOME, fotoItem.nomeVisualizzato)
        startActivity(intent)
    }
}

/** Adapter della griglia: carica le miniature in background con una piccola cache in memoria */
class PhotoAdapter(
    private val elenco: List<FotoItem>,
    private val executor: java.util.concurrent.ExecutorService,
    private val onClick: (FotoItem) -> Unit
) : RecyclerView.Adapter<PhotoAdapter.PhotoViewHolder>() {

    private val cache = HashMap<String, Bitmap>()

    inner class PhotoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivFoto: ImageView = itemView.findViewById(R.id.ivFoto)
        val tvNumero: TextView = itemView.findViewById(R.id.tvNumeroFotoCella)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_photo, parent, false)
        return PhotoViewHolder(view)
    }

    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
        val fotoItem = elenco[position]
        holder.tvNumero.text = fotoItem.numero.toString()
        holder.ivFoto.setImageBitmap(null)
        holder.itemView.setOnClickListener { onClick(fotoItem) }

        val chiaveCache = fotoItem.uri?.toString() ?: fotoItem.file?.absolutePath ?: return
        cache[chiaveCache]?.let {
            holder.ivFoto.setImageBitmap(it)
            return
        }

        executor.execute {
            val opzioni = BitmapFactory.Options().apply { inSampleSize = 4 }
            val bitmap: Bitmap? = try {
                if (fotoItem.uri != null) {
                    holder.itemView.context.contentResolver.openInputStream(fotoItem.uri)
                        ?.use { BitmapFactory.decodeStream(it, null, opzioni) }
                } else if (fotoItem.file != null) {
                    BitmapFactory.decodeFile(fotoItem.file.absolutePath, opzioni)
                } else null
            } catch (e: Exception) {
                null
            }

            if (bitmap != null) {
                cache[chiaveCache] = bitmap
                holder.itemView.post {
                    if (holder.adapterPosition == position) {
                        holder.ivFoto.setImageBitmap(bitmap)
                    }
                }
            }
        }
    }

    override fun getItemCount(): Int = elenco.size
}
