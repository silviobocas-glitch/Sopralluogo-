package com.example.sopralluoghi

import android.content.Context
import java.io.File

/**
 * Punto unico per la cartella dati privata dell'app dove vivono foto e video: usa la cartella
 * privata "esterna" dell'app (Android/data/<package>/files/Sopralluoghi), che:
 * - non richiede alcun permesso di storage (né su Android vecchi né nuovi)
 * - NON compare mai nella Galleria/nelle altre app di foto del telefono
 * - viene cancellata automaticamente dal sistema quando l'app viene disinstallata
 * - viene cancellata correttamente quando l'utente elimina un sopralluogo dall'app
 * Anche le note vivono qui, nella stessa cartella (vedi NotesHelper).
 */
object StorageHelper {
    private const val SOTTOCARTELLA = "Sopralluoghi"

    /** Cartella radice di tutti i sopralluoghi. Non torna mai null: se lo storage esterno
     * non fosse disponibile (caso raro), si appoggia allo storage interno privato dell'app. */
    fun cartellaRadice(context: Context): File {
        val base = context.getExternalFilesDir(null) ?: context.filesDir
        val radice = File(base, SOTTOCARTELLA)
        if (!radice.exists()) radice.mkdirs()
        // Marcatore che segnala a eventuali scanner di sistema di ignorare questa cartella:
        // non è strettamente necessario (Android/data non viene indicizzato in Galleria),
        // ma è una sicurezza in più che non costa nulla.
        try {
            val nomedia = File(radice, ".nomedia")
            if (!nomedia.exists()) nomedia.createNewFile()
        } catch (e: Exception) {
            // non blocca nulla se fallisce
        }
        return radice
    }

    /** Cartella dedicata a un singolo sopralluogo: qui vivono le sue foto e i suoi video. */
    fun cartellaSopralluogo(context: Context, nomeCartella: String): File {
        val cartella = File(cartellaRadice(context), nomeCartella)
        if (!cartella.exists()) cartella.mkdirs()
        return cartella
    }

    /** Elimina definitivamente e senza lasciare traccia tutti i file (foto, video, nota) di un sopralluogo. */
    fun eliminaCartellaSopralluogo(context: Context, nomeCartella: String) {
        try {
            File(cartellaRadice(context), nomeCartella).deleteRecursively()
        } catch (e: Exception) {
            // ignorato: se la cartella non esiste più non c'è nulla da eliminare
        }
    }

    /**
     * Rinomina la cartella di un sopralluogo e, insieme ad essa, tutte le foto/video già
     * salvati al suo interno (es. "Vecchio 1.jpg" -> "Nuovo 1.jpg"): senza questo passaggio
     * gli elementi già scattati sparirebbero dalla galleria, perché foto e video vengono
     * riconosciuti in base al prefisso col nome della cartella. Il file delle note non va
     * rinominato (si chiama sempre note.txt). Ritorna true se l'operazione è andata a buon fine.
     */
    fun rinominaCartellaSopralluogo(context: Context, vecchioNome: String, nuovoNome: String): Boolean {
        val cartellaVecchia = File(cartellaRadice(context), vecchioNome)
        val cartellaNuova = File(cartellaRadice(context), nuovoNome)
        if (cartellaNuova.exists()) return false

        if (!cartellaVecchia.exists()) {
            // Non c'era ancora nulla su disco (caso raro): basta creare la nuova cartella vuota.
            cartellaNuova.mkdirs()
            return true
        }

        if (!cartellaVecchia.renameTo(cartellaNuova)) return false

        val regex = Regex("^${Regex.escape(vecchioNome.trim())}\\s+(\\d+)", RegexOption.IGNORE_CASE)
        cartellaNuova.listFiles()?.forEach { file ->
            if (file.name.equals("note.txt", ignoreCase = true)) return@forEach
            val numero = regex.find(file.name.substringBeforeLast("."))?.groupValues?.get(1) ?: return@forEach
            val nuovoNomeFile = File(cartellaNuova, "$nuovoNome $numero.${file.extension}")
            if (!nuovoNomeFile.exists()) file.renameTo(nuovoNomeFile)
        }
        return true
    }
}
