package com.example.sopralluoghi

import android.content.Context
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ZipHelper {

    /** Crea uno zip (in cache) con tutte le foto, i video e la nota del sopralluogo, leggendo
     * direttamente dalla cartella privata dell'app dedicata a quel sopralluogo. Ritorna null in caso di errore. */
    fun creaZipDiCartella(context: Context, nomeCartella: String): File? {
        return try {
            val zipFile = File(context.cacheDir, "$nomeCartella.zip")
            if (zipFile.exists()) zipFile.delete()

            val cartella = StorageHelper.cartellaSopralluogo(context, nomeCartella)

            ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
                cartella.listFiles()?.forEach { file ->
                    if (!file.isFile) return@forEach
                    val nomeNelloZip = if (file.name.equals("note.txt", ignoreCase = true)) {
                        "$nomeCartella.txt"
                    } else {
                        file.name
                    }
                    try {
                        FileInputStream(file).use { input ->
                            zos.putNextEntry(ZipEntry(nomeNelloZip))
                            input.copyTo(zos)
                            zos.closeEntry()
                        }
                    } catch (e: Exception) {
                        // salta questo file e continua con gli altri
                    }
                }
            }
            zipFile
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Copia uno zip già creato (in cache) nella posizione scelta dall'utente tramite il
     * selettore di sistema (Storage Access Framework). È l'utente stesso a decidere cartella
     * e nome file nella schermata di sistema, quindi qui basta scrivere i byte nell'Uri
     * restituito. Ritorna true se la scrittura è andata a buon fine.
     */
    fun scriviZipSuUri(context: Context, zipFile: File, uriDestinazione: Uri): Boolean {
        return try {
            context.contentResolver.openOutputStream(uriDestinazione)?.use { output ->
                FileInputStream(zipFile).use { input -> input.copyTo(output) }
            } ?: return false
            true
        } catch (e: Exception) {
            false
        }
    }
}
