package com.example.sopralluoghi

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.concurrent.Executors

/** Rappresenta un elemento della galleria: foto o video, sempre come File nella cartella privata dell'app
 * (il campo uri è mantenuto solo per compatibilità con il codice che lo consuma, ma non viene più usato) */
data class FotoItem(
    val uri: Uri?,
    val file: File?,
    val numero: Int,
    val nomeVisualizzato: String,
    val isVideo: Boolean
)

/**
 * Contenitore in memoria condiviso tra GalleryActivity e FullImageActivity: evita di dover
 * serializzare tutta la lista (foto+video) in un Intent solo per permettere lo scorrimento
 * avanti/indietro nell'anteprima a schermo intero.
 */
object GalleriaCorrente {
    var elementi: List<FotoItem> = emptyList()
}

class GalleryActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NOME_CARTELLA = "NOME_CARTELLA"
    }

    private lateinit var nomeCartella: String
    private val elencoFoto = mutableListOf<FotoItem>()
    private lateinit var adapter: PhotoAdapter
    private val executor = Executors.newFixedThreadPool(3)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        nomeCartella = intent.getStringExtra(EXTRA_NOME_CARTELLA) ?: ""

        findViewById<TextView>(R.id.tvTitoloGalleria).text = nomeCartella
        val rv = findViewById<RecyclerView>(R.id.rvFoto)
        rv.layoutManager = GridLayoutManager(this, 3)
        adapter = PhotoAdapter(elencoFoto, executor) { fotoItem -> apriElemento(fotoItem) }
        rv.adapter = adapter

        caricaFoto()
    }

    override fun onResume() {
        super.onResume()
        // Ricarica ogni volta che si torna qui (es. dopo aver eliminato una foto)
        caricaFoto()
    }

    private fun caricaFoto() {
        Thread {
            val lista = mutableListOf<FotoItem>()
            try {
                val cartella = StorageHelper.cartellaSopralluogo(this, nomeCartella)
                cartella.listFiles()?.forEach { file ->
                    if (file.name.equals("note.txt", ignoreCase = true)) return@forEach
                    val numero = estraiNumero(file.name) ?: return@forEach
                    val isVideo = file.extension.equals("mp4", ignoreCase = true)
                    lista.add(FotoItem(null, file, numero, file.name, isVideo))
                }
            } catch (e: Exception) {
                // lista resta vuota o parziale
            }

            lista.sortBy { it.numero }

            runOnUiThread {
                elencoFoto.clear()
                elencoFoto.addAll(lista)
                adapter.notifyDataSetChanged()
                findViewById<TextView>(R.id.tvNumeroFoto).text = "${lista.size} elementi"
                findViewById<View>(R.id.tvNessunaFoto).visibility =
                    if (lista.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    /**
     * Estrae il numero progressivo dal nome del file (es. "Castano 4.jpg" -> 4).
     * Non è sensibile a maiuscole/minuscole o spazi extra, e ignora eventuali suffissi
     * come "(1)" che Android aggiunge da solo se esiste già un file con lo stesso nome:
     * un confronto troppo rigido faceva sì che la numerazione sparisse (mostrando sempre 0)
     * appena il nome non coincideva byte per byte.
     */
    private fun estraiNumero(nomeFile: String): Int? {
        val senzaEstensione = nomeFile.substringBeforeLast(".").trim()
        val regex = Regex("^${Regex.escape(nomeCartella.trim())}\\s+(\\d+)", RegexOption.IGNORE_CASE)
        return regex.find(senzaEstensione)?.groupValues?.get(1)?.toIntOrNull()
    }

    private fun apriElemento(fotoItem: FotoItem) {
        val indice = elencoFoto.indexOf(fotoItem)
        if (indice == -1) return

        GalleriaCorrente.elementi = elencoFoto.toList()

        val intent = Intent(this, FullImageActivity::class.java)
        intent.putExtra(FullImageActivity.EXTRA_INDICE, indice)
        startActivity(intent)
    }
}

/** Adapter della griglia: carica le miniature in background con una piccola cache in memoria */
class PhotoAdapter(
    private val elenco: List<FotoItem>,
    private val executor: java.util.concurrent.ExecutorService,
    private val onClick: (FotoItem) -> Unit
) : RecyclerView.Adapter<PhotoAdapter.PhotoViewHolder>() {

    private val cache = HashMap<String, Bitmap>()

    inner class PhotoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivFoto: ImageView = itemView.findViewById(R.id.ivFoto)
        val tvNumero: TextView = itemView.findViewById(R.id.tvNumeroFotoCella)
        val ivIconaVideo: TextView = itemView.findViewById(R.id.ivIconaVideo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_photo, parent, false)
        return PhotoViewHolder(view)
    }

    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
        val fotoItem = elenco[position]
        holder.tvNumero.text = fotoItem.numero.toString()
        holder.ivFoto.setImageBitmap(null)
        holder.ivIconaVideo.visibility = if (fotoItem.isVideo) View.VISIBLE else View.GONE
        holder.itemView.setOnClickListener { onClick(fotoItem) }

        val chiaveCache = fotoItem.uri?.toString() ?: fotoItem.file?.absolutePath ?: return
        cache[chiaveCache]?.let {
            holder.ivFoto.setImageBitmap(it)
            return
        }

        executor.execute {
            val bitmap = if (fotoItem.isVideo) {
                caricaMiniaturaVideo(holder.itemView.context, fotoItem)
            } else {
                ImmagineUtils.caricaBitmapCorretto(
                    holder.itemView.context, fotoItem.uri, fotoItem.file, inSampleSize = 4
                )
            }

            if (bitmap != null) {
                cache[chiaveCache] = bitmap
                holder.itemView.post {
                    if (holder.adapterPosition == position) {
                        holder.ivFoto.setImageBitmap(bitmap)
                    }
                }
            }
        }
    }

    private fun caricaMiniaturaVideo(context: android.content.Context, fotoItem: FotoItem): Bitmap? {
        return try {
            val retriever = android.media.MediaMetadataRetriever()
            if (fotoItem.uri != null) {
                retriever.setDataSource(context, fotoItem.uri)
            } else if (fotoItem.file != null) {
                retriever.setDataSource(fotoItem.file.absolutePath)
            }
            val frame = retriever.getFrameAtTime(0)
            retriever.release()
            frame
        } catch (e: Exception) {
            null
        }
    }

    override fun getItemCount(): Int = elenco.size
}
