package com.example.sopralluoghi

import android.content.Context
import java.io.File

/**
 * Punto unico per tutta la cartella dati dell'app: usa la cartella privata
 * "esterna" dell'app (Android/data/<package>/files/Sopralluoghi), che:
 * - non richiede alcun permesso di storage (né su Android vecchi né nuovi)
 * - NON compare mai nella Galleria/nelle altre app di foto del telefono
 * - viene cancellata automaticamente dal sistema quando l'app viene disinstallata
 * - viene cancellata correttamente quando l'utente elimina un sopralluogo dall'app,
 *   perché foto, video e note di quel sopralluogo stanno tutti nella stessa sotto-cartella
 */
object StorageHelper {
    private const val SOTTOCARTELLA = "Sopralluoghi"

    /** Cartella radice di tutti i sopralluoghi. Non torna mai null: se lo storage esterno
     * non fosse disponibile (caso raro), si appoggia allo storage interno privato dell'app. */
    fun cartellaRadice(context: Context): File {
        val base = context.getExternalFilesDir(null) ?: context.filesDir
        val radice = File(base, SOTTOCARTELLA)
        if (!radice.exists()) radice.mkdirs()
        // Marcatore che segnala a eventuali scanner di sistema di ignorare questa cartella:
        // non è strettamente necessario (Android/data non viene indicizzato in Galleria),
        // ma è una sicurezza in più che non costa nulla.
        try {
            val nomedia = File(radice, ".nomedia")
            if (!nomedia.exists()) nomedia.createNewFile()
        } catch (e: Exception) {
            // non blocca nulla se fallisce
        }
        return radice
    }

    /** Cartella dedicata a un singolo sopralluogo: qui vivono le sue foto, i suoi video e la sua nota. */
    fun cartellaSopralluogo(context: Context, nomeCartella: String): File {
        val cartella = File(cartellaRadice(context), nomeCartella)
        if (!cartella.exists()) cartella.mkdirs()
        return cartella
    }

    /** Elimina definitivamente e senza lasciare traccia tutti i file (foto, video, nota) di un sopralluogo. */
    fun eliminaCartellaSopralluogo(context: Context, nomeCartella: String) {
        try {
            File(cartellaRadice(context), nomeCartella).deleteRecursively()
        } catch (e: Exception) {
            // ignorato: se la cartella non esiste più non c'è nulla da eliminare
        }
    }
}
