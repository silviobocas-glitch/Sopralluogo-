package com.example.sopralluoghi

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.concurrent.Executors

/** Rappresenta un elemento della galleria: foto o video, che venga da MediaStore (Uri) o da file diretto */
data class FotoItem(
    val uri: Uri?,
    val file: File?,
    val numero: Int,
    val nomeVisualizzato: String,
    val isVideo: Boolean
)

class GalleryActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NOME_CARTELLA = "NOME_CARTELLA"
        private const val SOTTOCARTELLA = "Sopralluoghi"
    }

    private lateinit var nomeCartella: String
    private val elencoFoto = mutableListOf<FotoItem>()
    private lateinit var adapter: PhotoAdapter
    private val executor = Executors.newFixedThreadPool(3)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        nomeCartella = intent.getStringExtra(EXTRA_NOME_CARTELLA) ?: ""

        findViewById<TextView>(R.id.tvTitoloGalleria).text = nomeCartella
        val rv = findViewById<RecyclerView>(R.id.rvFoto)
        rv.layoutManager = GridLayoutManager(this, 3)
        adapter = PhotoAdapter(elencoFoto, executor) { fotoItem -> apriElemento(fotoItem) }
        rv.adapter = adapter

        caricaFoto()
    }

    override fun onResume() {
        super.onResume()
        // Ricarica ogni volta che si torna qui (es. dopo aver eliminato una foto)
        caricaFoto()
    }

    private fun caricaFoto() {
        Thread {
            val lista = mutableListOf<FotoItem>()
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    aggiungiDaMediaStore(
                        lista,
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella/",
                        isVideo = false
                    )
                    aggiungiDaMediaStore(
                        lista,
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        "${Environment.DIRECTORY_MOVIES}/$SOTTOCARTELLA/$nomeCartella/",
                        isVideo = true
                    )
                } else {
                    val cartellaFoto = File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                        "$SOTTOCARTELLA/$nomeCartella"
                    )
                    cartellaFoto.listFiles()?.forEach { file ->
                        val numero = estraiNumero(file.name) ?: 0
                        lista.add(FotoItem(null, file, numero, file.name, isVideo = false))
                    }
                    val cartellaVideo = File(
                        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                        "$SOTTOCARTELLA/$nomeCartella"
                    )
                    cartellaVideo.listFiles()?.forEach { file ->
                        val numero = estraiNumero(file.name) ?: 0
                        lista.add(FotoItem(null, file, numero, file.name, isVideo = true))
                    }
                }
            } catch (e: Exception) {
                // lista resta vuota o parziale
            }

            lista.sortByDescending { it.numero }

            runOnUiThread {
                elencoFoto.clear()
                elencoFoto.addAll(lista)
                adapter.notifyDataSetChanged()
                findViewById<TextView>(R.id.tvNumeroFoto).text = "${lista.size} elementi"
                findViewById<View>(R.id.tvNessunaFoto).visibility =
                    if (lista.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    private fun aggiungiDaMediaStore(
        lista: MutableList<FotoItem>,
        collectionUri: Uri,
        relativePath: String,
        isVideo: Boolean
    ) {
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
        val selectionArgs = arrayOf(relativePath)
        contentResolver.query(collectionUri, projection, selection, selectionArgs, null)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val displayName = cursor.getString(nameCol)
                val numero = estraiNumero(displayName) ?: 0
                val uri = Uri.withAppendedPath(collectionUri, id.toString())
                lista.add(FotoItem(uri, null, numero, displayName, isVideo))
            }
        }
    }

    private fun estraiNumero(nomeFile: String): Int? {
        val senzaEstensione = nomeFile.substringBeforeLast(".")
        val prefisso = "$nomeCartella "
        if (!senzaEstensione.startsWith(prefisso)) return null
        return senzaEstensione.removePrefix(prefisso).toIntOrNull()
    }

    private fun apriElemento(fotoItem: FotoItem) {
        if (fotoItem.isVideo) {
            apriVideo(fotoItem)
        } else {
            val intent = Intent(this, FullImageActivity::class.java)
            intent.putExtra(FullImageActivity.EXTRA_URI, fotoItem.uri)
            intent.putExtra(FullImageActivity.EXTRA_FILE_PATH, fotoItem.file?.absolutePath)
            intent.putExtra(FullImageActivity.EXTRA_NOME, fotoItem.nomeVisualizzato)
            startActivity(intent)
        }
    }

    /** Apre il video con il player predefinito del telefono */
    private fun apriVideo(fotoItem: FotoItem) {
        try {
            val uriDaAprire = fotoItem.uri ?: fotoItem.file?.let {
                FileProvider.getUriForFile(this, "$packageName.fileprovider", it)
            } ?: return

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uriDaAprire, "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Nessuna app disponibile per riprodurre il video", Toast.LENGTH_LONG).show()
        }
    }
}

/** Adapter della griglia: carica le miniature in background con una piccola cache in memoria */
class PhotoAdapter(
    private val elenco: List<FotoItem>,
    private val executor: java.util.concurrent.ExecutorService,
    private val onClick: (FotoItem) -> Unit
) : RecyclerView.Adapter<PhotoAdapter.PhotoViewHolder>() {

    private val cache = HashMap<String, Bitmap>()

    inner class PhotoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivFoto: ImageView = itemView.findViewById(R.id.ivFoto)
        val tvNumero: TextView = itemView.findViewById(R.id.tvNumeroFotoCella)
        val ivIconaVideo: TextView = itemView.findViewById(R.id.ivIconaVideo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_photo, parent, false)
        return PhotoViewHolder(view)
    }

    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
        val fotoItem = elenco[position]
        holder.tvNumero.text = fotoItem.numero.toString()
        holder.ivFoto.setImageBitmap(null)
        holder.ivIconaVideo.visibility = if (fotoItem.isVideo) View.VISIBLE else View.GONE
        holder.itemView.setOnClickListener { onClick(fotoItem) }

        val chiaveCache = fotoItem.uri?.toString() ?: fotoItem.file?.absolutePath ?: return
        cache[chiaveCache]?.let {
            holder.ivFoto.setImageBitmap(it)
            return
        }

        executor.execute {
            val bitmap = if (fotoItem.isVideo) {
                caricaMiniaturaVideo(holder.itemView.context, fotoItem)
            } else {
                ImmagineUtils.caricaBitmapCorretto(
                    holder.itemView.context, fotoItem.uri, fotoItem.file, inSampleSize = 4
                )
            }

            if (bitmap != null) {
                cache[chiaveCache] = bitmap
                holder.itemView.post {
                    if (holder.adapterPosition == position) {
                        holder.ivFoto.setImageBitmap(bitmap)
                    }
                }
            }
        }
    }

    private fun caricaMiniaturaVideo(context: android.content.Context, fotoItem: FotoItem): Bitmap? {
        return try {
            val retriever = android.media.MediaMetadataRetriever()
            if (fotoItem.uri != null) {
                retriever.setDataSource(context, fotoItem.uri)
            } else if (fotoItem.file != null) {
                retriever.setDataSource(fotoItem.file.absolutePath)
            }
            val frame = retriever.getFrameAtTime(0)
            retriever.release()
            frame
        } catch (e: Exception) {
            null
        }
    }

    override fun getItemCount(): Int = elenco.size
}
