package com.example.sopralluoghi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider

class FolderActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NOME = "NOME_CARTELLA"
    }

    private lateinit var nomeCartella: String

    private val richiestaPermessi = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { risultati ->
        if (risultati.values.all { it }) {
            avviaFotocamera()
        } else {
            Toast.makeText(this, "Serve il permesso fotocamera per continuare", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_folder)

        nomeCartella = intent.getStringExtra(EXTRA_NOME) ?: run {
            finish()
            return
        }

        findViewById<TextView>(R.id.tvTitoloCartella).text = nomeCartella

        findViewById<View>(R.id.btnFotocamera).setOnClickListener { controllaPermessiEAvviaFotocamera() }

        findViewById<View>(R.id.btnVediFoto).setOnClickListener {
            val intent = Intent(this, GalleryActivity::class.java)
            intent.putExtra(GalleryActivity.EXTRA_NOME_CARTELLA, nomeCartella)
            startActivity(intent)
        }

        findViewById<View>(R.id.btnNote).setOnClickListener {
            val intent = Intent(this, NotesActivity::class.java)
            intent.putExtra(NotesActivity.EXTRA_NOME, nomeCartella)
            startActivity(intent)
        }

        findViewById<View>(R.id.btnCondividi).setOnClickListener { condividiCartella() }

        findViewById<View>(R.id.btnSalva).setOnClickListener { salvaCartella() }
    }

    private fun controllaPermessiEAvviaFotocamera() {
        val permessiNecessari = mutableListOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            permessiNecessari.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val mancanti = permessiNecessari.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (mancanti.isEmpty()) {
            avviaFotocamera()
        } else {
            richiestaPermessi.launch(mancanti.toTypedArray())
        }
    }

    private fun avviaFotocamera() {
        val intent = Intent(this, CameraActivity::class.java)
        intent.putExtra(CameraActivity.EXTRA_NOME_SOPRALLUOGO, nomeCartella)
        startActivity(intent)
    }

    private fun condividiCartella() {
        Toast.makeText(this, "Preparo il file da condividere...", Toast.LENGTH_SHORT).show()
        Thread {
            val zipFile = ZipHelper.creaZipDiCartella(this, nomeCartella)
            runOnUiThread {
                if (zipFile != null) {
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", zipFile)
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/zip"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(shareIntent, "Condividi $nomeCartella"))
                } else {
                    Toast.makeText(this, "Errore nella creazione dello zip", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun salvaCartella() {
        Toast.makeText(this, "Salvo il file in Documenti...", Toast.LENGTH_SHORT).show()
        Thread {
            val riuscito = ZipHelper.salvaZipInDocumenti(this, nomeCartella)
            runOnUiThread {
                if (riuscito) {
                    Toast.makeText(this, "Zip salvato nella cartella Documenti", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Errore nel salvataggio dello zip", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
