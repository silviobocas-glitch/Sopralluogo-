package com.example.sopralluoghi

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.card.MaterialCardView

class FolderAdapter(
    private val elenco: List<String>,
    private val onNuovo: () -> Unit,
    private val onApri: (String) -> Unit,
    private val onLongClick: (String) -> Unit
) : RecyclerView.Adapter<FolderAdapter.TileViewHolder>() {

    class TileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val root: MaterialCardView = itemView.findViewById(R.id.rootTile)
        val icona: TextView = itemView.findViewById(R.id.tvIconaCartella)
        val iconaImage: ImageView = itemView.findViewById(R.id.ivIconaCartella)
        val nome: TextView = itemView.findViewById(R.id.tvNomeCartella)
        val sottotitolo: TextView = itemView.findViewById(R.id.tvSottotitoloCartella)
    }

    override fun getItemCount(): Int = elenco.size + 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TileViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder_tile, parent, false)
        return TileViewHolder(view)
    }

    override fun onBindViewHolder(holder: TileViewHolder, position: Int) {
        val context = holder.itemView.context
        if (position == 0) {
            holder.root.setCardBackgroundColor(ContextCompat.getColor(context, R.color.surface))
            holder.root.strokeColor = ContextCompat.getColor(context, R.color.blue)
            holder.iconaImage.setImageResource(R.drawable.ic_plus)
            holder.iconaImage.alpha = 1f
            holder.nome.text = "Nuovo sopralluogo"
            holder.nome.setTextColor(ContextCompat.getColor(context, R.color.text_primary))
            holder.sottotitolo.text = "Tocca per iniziare"
            holder.itemView.setOnClickListener { onNuovo() }
            holder.itemView.setOnLongClickListener(null)
            holder.itemView.isLongClickable = false
        } else {
            val nome = elenco[position - 1]
            holder.root.setCardBackgroundColor(ContextCompat.getColor(context, R.color.blue))
            holder.root.strokeColor = ContextCompat.getColor(context, R.color.blue)
            holder.iconaImage.setImageResource(R.drawable.ic_folder)
            holder.nome.text = nome
            holder.nome.setTextColor(ContextCompat.getColor(context, android.R.color.white))
            holder.sottotitolo.text = "Tocca per aprire"
            holder.sottotitolo.setTextColor(0xFFDCE6FF.toInt())
            holder.itemView.setOnClickListener { onApri(nome) }
            holder.itemView.setOnLongClickListener {
                onLongClick(nome)
                true
            }
        }
    }
}
