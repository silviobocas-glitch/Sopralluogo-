package com.example.sopralluoghi

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ZipHelper {
    private const val SOTTOCARTELLA = "Sopralluoghi"

    /** Crea uno zip (in cache) con tutte le foto, i video e la nota del sopralluogo. Ritorna null in caso di errore. */
    fun creaZipDiCartella(context: Context, nomeCartella: String): File? {
        return try {
            val zipFile = File(context.cacheDir, "$nomeCartella.zip")
            if (zipFile.exists()) zipFile.delete()

            // Nomi già inseriti nello zip, per evitare doppioni tra la cartella unificata e i vecchi percorsi
            val nomiGiaAggiunti = mutableSetOf<String>()

            ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
                // Posizione attuale: foto, video e note sono tutti archiviati insieme in Documents/Sopralluoghi/<nome>
                aggiungiCartellaSopralluogoAllozip(nomeCartella, zos, nomiGiaAggiunti)
                // Compatibilità con sopralluoghi creati da versioni precedenti dell'app
                aggiungiVecchieFotoAllozip(context, nomeCartella, zos, nomiGiaAggiunti)
                aggiungiVecchiVideoAllozip(context, nomeCartella, zos, nomiGiaAggiunti)
            }
            zipFile
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Copia uno zip già creato (in cache) nella posizione scelta dall'utente tramite il
     * selettore di sistema (Storage Access Framework). È l'utente stesso a decidere cartella
     * e nome file nella schermata di sistema, quindi qui basta scrivere i byte nell'Uri
     * restituito. Ritorna true se la scrittura è andata a buon fine.
     */
    fun scriviZipSuUri(context: Context, zipFile: File, uriDestinazione: Uri): Boolean {
        return try {
            context.contentResolver.openOutputStream(uriDestinazione)?.use { output ->
                FileInputStream(zipFile).use { input -> input.copyTo(output) }
            } ?: return false
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Aggiunge tutto il contenuto (foto, video, note.txt) della cartella unificata Documents/Sopralluoghi/<nome> */
    private fun aggiungiCartellaSopralluogoAllozip(
        nomeCartella: String,
        zos: ZipOutputStream,
        nomiGiaAggiunti: MutableSet<String>
    ) {
        val cartella = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
            "$SOTTOCARTELLA/$nomeCartella"
        )
        cartella.listFiles()?.forEach { file ->
            val nomeZip = if (file.name.equals("note.txt", ignoreCase = true)) "$nomeCartella.txt" else file.name
            try {
                FileInputStream(file).use { input ->
                    zos.putNextEntry(ZipEntry(nomeZip))
                    input.copyTo(zos)
                    zos.closeEntry()
                }
                nomiGiaAggiunti.add(file.name)
            } catch (e: Exception) {
                // salta questo file e continua con gli altri
            }
        }
    }

    /** Compatibilità: foto salvate prima di questo aggiornamento, quando finivano in Pictures tramite MediaStore */
    private fun aggiungiVecchieFotoAllozip(
        context: Context,
        nomeCartella: String,
        zos: ZipOutputStream,
        nomiGiaAggiunti: MutableSet<String>
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella/"
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                arrayOf(relativePath),
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.getString(nameCol)
                    if (!nomiGiaAggiunti.add(displayName)) continue
                    val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                    try {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            zos.putNextEntry(ZipEntry(displayName))
                            input.copyTo(zos)
                            zos.closeEntry()
                        }
                    } catch (e: Exception) {
                        // salta questa foto e continua con le altre
                    }
                }
            }
        } else {
            val cartellaPubblica = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "$SOTTOCARTELLA/$nomeCartella"
            )
            cartellaPubblica.listFiles()?.forEach { file ->
                if (!nomiGiaAggiunti.add(file.name)) return@forEach
                try {
                    FileInputStream(file).use { input ->
                        zos.putNextEntry(ZipEntry(file.name))
                        input.copyTo(zos)
                        zos.closeEntry()
                    }
                } catch (e: Exception) {
                    // salta questo file
                }
            }
        }
    }

    /** Compatibilità: video salvati prima di questo aggiornamento, quando finivano in Movies tramite MediaStore */
    private fun aggiungiVecchiVideoAllozip(
        context: Context,
        nomeCartella: String,
        zos: ZipOutputStream,
        nomiGiaAggiunti: MutableSet<String>
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_MOVIES}/$SOTTOCARTELLA/$nomeCartella/"
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                arrayOf(relativePath),
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.getString(nameCol)
                    if (!nomiGiaAggiunti.add(displayName)) continue
                    val uri = Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString())
                    try {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            zos.putNextEntry(ZipEntry(displayName))
                            input.copyTo(zos)
                            zos.closeEntry()
                        }
                    } catch (e: Exception) {
                        // salta questo video e continua con gli altri
                    }
                }
            }
        } else {
            val cartellaPubblica = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "$SOTTOCARTELLA/$nomeCartella"
            )
            cartellaPubblica.listFiles()?.forEach { file ->
                if (!nomiGiaAggiunti.add(file.name)) return@forEach
                try {
                    FileInputStream(file).use { input ->
                        zos.putNextEntry(ZipEntry(file.name))
                        input.copyTo(zos)
                        zos.closeEntry()
                    }
                } catch (e: Exception) {
                    // salta questo file
                }
            }
        }
    }
}
