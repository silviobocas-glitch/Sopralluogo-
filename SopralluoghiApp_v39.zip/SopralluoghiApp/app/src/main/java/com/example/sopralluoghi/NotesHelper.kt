package com.example.sopralluoghi

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/**
 * Le note vivono nella cartella di sistema Documents (Documents/Sopralluoghi/<nome>/note.txt),
 * a differenza di foto e video che restano nella cartella privata dell'app (vedi StorageHelper).
 * Essendo nella cartella di sistema, la nota resta visibile/apribile anche da altre app (es. un
 * gestore di file) e — a differenza di foto e video — NON viene rimossa automaticamente se l'app
 * viene disinstallata: viene però sempre eliminata quando il sopralluogo viene eliminato dall'app.
 */
object NotesHelper {
    private const val SOTTOCARTELLA = "Sopralluoghi"
    private const val NOME_FILE = "note.txt"

    private fun percorsoRelativo(nomeCartella: String) =
        "${Environment.DIRECTORY_DOCUMENTS}/$SOTTOCARTELLA/$nomeCartella/"

    fun leggiNota(context: Context, nomeCartella: String): String {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = trovaUriNotaEsistente(context, nomeCartella) ?: return ""
                context.contentResolver.openInputStream(uri)?.use { it.bufferedReader().readText() } ?: ""
            } else {
                val file = fileNotaLegacy(nomeCartella)
                if (file.exists()) file.readText() else ""
            }
        } catch (e: Exception) {
            ""
        }
    }

    fun salvaNota(context: Context, nomeCartella: String, testo: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uriEsistente = trovaUriNotaEsistente(context, nomeCartella)
                val uri = uriEsistente ?: run {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, NOME_FILE)
                        put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, percorsoRelativo(nomeCartella))
                    }
                    context.contentResolver.insert(MediaStore.Files.getContentUri("external"), contentValues)
                } ?: return
                // "wt" = write troncando il contenuto precedente, altrimenti si rischia di
                // accodare o lasciare "coda" di testo vecchio se la nuova nota è più corta
                context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(testo.toByteArray()) }
            } else {
                val file = fileNotaLegacy(nomeCartella)
                file.parentFile?.mkdirs()
                file.writeText(testo)
            }
        } catch (e: Exception) {
            // se il salvataggio fallisce non blocchiamo l'uscita dalla schermata
        }
    }

    /** Elimina la nota (e la sua cartella in Documents) di un sopralluogo, senza lasciarne traccia sul telefono. */
    fun eliminaNota(context: Context, nomeCartella: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                context.contentResolver.delete(
                    MediaStore.Files.getContentUri("external"),
                    "${MediaStore.MediaColumns.RELATIVE_PATH} = ?",
                    arrayOf(percorsoRelativo(nomeCartella))
                )
            } else {
                fileCartellaLegacy(nomeCartella).deleteRecursively()
            }
        } catch (e: Exception) {
            // ignorato
        }
    }

    private fun trovaUriNotaEsistente(context: Context, nomeCartella: String): Uri? {
        val projection = arrayOf(MediaStore.MediaColumns._ID)
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ? AND ${MediaStore.MediaColumns.DISPLAY_NAME} = ?"
        val selectionArgs = arrayOf(percorsoRelativo(nomeCartella), NOME_FILE)
        context.contentResolver.query(
            MediaStore.Files.getContentUri("external"),
            projection, selection, selectionArgs, null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID))
                return Uri.withAppendedPath(MediaStore.Files.getContentUri("external"), id.toString())
            }
        }
        return null
    }

    private fun fileNotaLegacy(nomeCartella: String): File = File(fileCartellaLegacy(nomeCartella), NOME_FILE)

    private fun fileCartellaLegacy(nomeCartella: String): File = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
        "$SOTTOCARTELLA/$nomeCartella"
    )
}
