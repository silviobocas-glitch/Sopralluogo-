package com.example.sopralluoghi

import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class NotesActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NOME = "NOME_CARTELLA"
    }

    private lateinit var nomeCartella: String
    private lateinit var etNote: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notes)

        nomeCartella = intent.getStringExtra(EXTRA_NOME) ?: run {
            finish()
            return
        }

        findViewById<TextView>(R.id.tvTitoloNote).text = "Note — $nomeCartella"
        etNote = findViewById(R.id.etNote)
        etNote.setText(NotesHelper.leggiNota(this, nomeCartella))
    }

    override fun onPause() {
        super.onPause()
        NotesHelper.salvaNota(this, nomeCartella, etNote.text.toString())
    }
}
