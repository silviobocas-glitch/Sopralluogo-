package com.example.sopralluoghi

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat

/**
 * Verifica se l'app può scrivere/leggere/eliminare file nella cartella di sistema Documents
 * (dove vengono archiviate le note dei sopralluoghi).
 *
 * - Da Android 11 (API 30) in poi, per scrivere fuori dalle cartelle Pictures/Movies/Music/Download
 *   serve il permesso speciale "Tutti i file" (MANAGE_EXTERNAL_STORAGE), concedibile solo dalle
 *   Impostazioni di sistema: non esiste un pop-up di richiesta a runtime come per gli altri permessi.
 * - Prima di Android 11 (con requestLegacyExternalStorage attivo) basta il normale permesso
 *   di scrittura sullo storage (WRITE_EXTERNAL_STORAGE), richiedibile a runtime.
 */
object PermessiArchiviazione {

    fun accessoDocumentiConcesso(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }
    }
}
