package com.example.sopralluoghi

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class FolderAdapter(
    private val elenco: List<String>,
    private val onNuovo: () -> Unit,
    private val onApri: (String) -> Unit,
    private val onLongClick: (String) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TIPO_NUOVO = 0
        private const val TIPO_CARTELLA = 1
    }

    /** Cella "Nuovo": rettangolo a tutta larghezza, sempre in prima posizione */
    class NuovoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val icona: TextView = itemView.findViewById(R.id.tvIconaCartella)
        val nome: TextView = itemView.findViewById(R.id.tvNomeCartella)
        val sottotitolo: TextView = itemView.findViewById(R.id.tvSottotitoloCartella)
    }

    /** Cella di una cartella già creata */
    class TileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val root: View = itemView.findViewById(R.id.rootTile)
        val icona: TextView = itemView.findViewById(R.id.tvIconaCartella)
        val nome: TextView = itemView.findViewById(R.id.tvNomeCartella)
        val sottotitolo: TextView = itemView.findViewById(R.id.tvSottotitoloCartella)
        val chevron: TextView = itemView.findViewById(R.id.tvChevronCartella)
    }

    override fun getItemCount(): Int = elenco.size + 1

    override fun getItemViewType(position: Int): Int {
        return if (position == 0) TIPO_NUOVO else TIPO_CARTELLA
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == TIPO_NUOVO) {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder_tile_nuovo, parent, false)
            NuovoViewHolder(view)
        } else {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder_tile, parent, false)
            TileViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val context = holder.itemView.context

        if (holder is NuovoViewHolder) {
            holder.icona.background = ContextCompat.getDrawable(context, R.drawable.bg_icon_badge_blu_chiaro)
            holder.icona.text = "➕"
            holder.icona.setTextColor(ContextCompat.getColor(context, R.color.colore_cartella_blu))
            holder.nome.text = "Nuovo"
            holder.nome.setTextColor(ContextCompat.getColor(context, R.color.colore_testo_scuro))
            holder.sottotitolo.text = "Tocca per creare"
            holder.sottotitolo.setTextColor(ContextCompat.getColor(context, R.color.colore_testo_grigio))
            holder.itemView.setOnClickListener { onNuovo() }
            holder.itemView.setOnLongClickListener(null)
            holder.itemView.isLongClickable = false
        } else if (holder is TileViewHolder) {
            val nome = elenco[position - 1]
            holder.root.setBackgroundResource(R.drawable.bg_folder)
            holder.icona.background = ContextCompat.getDrawable(context, R.drawable.bg_icon_badge_white)
            holder.icona.text = "📁"
            holder.icona.setTextColor(ContextCompat.getColor(context, android.R.color.black))
            holder.nome.text = nome
            holder.nome.setTextColor(ContextCompat.getColor(context, android.R.color.white))
            holder.sottotitolo.text = "Tocca per aprire"
            holder.sottotitolo.setTextColor(0xCCFFFFFF.toInt())
            holder.chevron.visibility = View.VISIBLE
            holder.itemView.setOnClickListener { onApri(nome) }
            holder.itemView.setOnLongClickListener {
                onLongClick(nome)
                true
            }
        }
    }
}
