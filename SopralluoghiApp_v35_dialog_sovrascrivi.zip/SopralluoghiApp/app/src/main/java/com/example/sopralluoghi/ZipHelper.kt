package com.example.sopralluoghi

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ZipHelper {
    private const val SOTTOCARTELLA = "Sopralluoghi"

    /** Crea uno zip (in cache) con tutte le foto e la nota del sopralluogo. Ritorna null in caso di errore. */
    fun creaZipDiCartella(context: Context, nomeCartella: String): File? {
        return try {
            val zipFile = File(context.cacheDir, "$nomeCartella.zip")
            if (zipFile.exists()) zipFile.delete()

            ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
                aggiungiFotoAllozip(context, nomeCartella, zos)
                aggiungiVideoAllozip(context, nomeCartella, zos)
                aggiungiNotaAllozip(context, nomeCartella, zos)
            }
            zipFile
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Controlla se in Documenti esiste già uno zip con questo nome, per poter
     * chiedere all'utente se vuole sovrascriverlo o salvarne una copia separata.
     */
    fun esisteZipInDocumenti(context: Context, nomeCartella: String): Boolean {
        val nomeFile = "$nomeCartella.zip"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            trovaUriEsistente(context, nomeFile) != null
        } else {
            val cartellaDocumenti = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            File(cartellaDocumenti, nomeFile).exists()
        }
    }

    private fun trovaUriEsistente(context: Context, nomeFile: String): Uri? {
        val resolver = context.contentResolver
        val collection = MediaStore.Files.getContentUri("external")
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.RELATIVE_PATH)
        // Filtriamo solo per nome nella query SQL: il confronto sul percorso lo facciamo
        // dopo in Kotlin, perché il formato esatto di RELATIVE_PATH (slash finale, ecc.)
        // può variare tra produttori e versioni di Android.
        val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} = ?"
        return try {
            resolver.query(
                collection,
                projection,
                selection,
                arrayOf(nomeFile),
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val pathCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
                while (cursor.moveToNext()) {
                    val percorso = cursor.getString(pathCol) ?: ""
                    if (percorso.trimEnd('/').equals("Documents", ignoreCase = true)) {
                        val id = cursor.getLong(idCol)
                        return Uri.withAppendedPath(collection, id.toString())
                    }
                }
                null
            }
        } catch (e: Exception) {
            // Se non riusciamo a interrogare MediaStore (es. permesso mancante su alcuni
            // dispositivi), meglio considerare "non trovato" piuttosto che bloccare il salvataggio.
            null
        }
    }

    /** Genera un nome tipo "nome (2).zip" non ancora usato, per il caso "salva comunque". */
    private fun nomeFileUnivoco(context: Context, nomeCartella: String): String {
        var tentativo = 1
        var nomeFile: String
        do {
            tentativo++
            nomeFile = "$nomeCartella ($tentativo).zip"
        } while (
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                trovaUriEsistente(context, nomeFile) != null
            } else {
                val cartellaDocumenti = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
                File(cartellaDocumenti, nomeFile).exists()
            }
        )
        return nomeFile
    }

    /**
     * Crea lo zip della cartella e lo salva direttamente nella cartella pubblica "Documenti"
     * del dispositivo, così resta disponibile da qualsiasi gestore file senza dover passare
     * dalla condivisione. Ritorna true se il salvataggio è andato a buon fine.
     *
     * @param sovrascrivi se true e un file con lo stesso nome esiste già, lo sostituisce;
     *                    se false, salva una copia con un nome numerato ("nome (2).zip").
     */
    fun salvaZipInDocumenti(context: Context, nomeCartella: String, sovrascrivi: Boolean = false): Boolean {
        val zipFile = creaZipDiCartella(context, nomeCartella) ?: return false
        val nomeFileDefault = "$nomeCartella.zip"

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val collection = MediaStore.Files.getContentUri("external")
                val uriEsistente = trovaUriEsistente(context, nomeFileDefault)

                val uri: Uri = if (uriEsistente != null && sovrascrivi) {
                    uriEsistente
                } else {
                    val nomeFile = if (uriEsistente != null) nomeFileUnivoco(context, nomeCartella) else nomeFileDefault
                    val values = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, nomeFile)
                        put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOCUMENTS)
                    }
                    resolver.insert(collection, values) ?: return false
                }

                // "wt" tronca il file esistente prima di scrivere, per una vera sovrascrittura
                resolver.openOutputStream(uri, "wt")?.use { output ->
                    FileInputStream(zipFile).use { input -> input.copyTo(output) }
                } ?: return false
                true
            } else {
                val cartellaDocumenti = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
                if (!cartellaDocumenti.exists()) cartellaDocumenti.mkdirs()
                val destinazioneEsistente = File(cartellaDocumenti, nomeFileDefault)
                val nomeFile = if (destinazioneEsistente.exists() && !sovrascrivi) {
                    nomeFileUnivoco(context, nomeCartella)
                } else {
                    nomeFileDefault
                }
                val destinazione = File(cartellaDocumenti, nomeFile)
                FileInputStream(zipFile).use { input ->
                    FileOutputStream(destinazione).use { output -> input.copyTo(output) }
                }
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun aggiungiFotoAllozip(context: Context, nomeCartella: String, zos: ZipOutputStream) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella/"
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                arrayOf(relativePath),
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.getString(nameCol)
                    val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                    try {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            zos.putNextEntry(ZipEntry(displayName))
                            input.copyTo(zos)
                            zos.closeEntry()
                        }
                    } catch (e: Exception) {
                        // salta questa foto e continua con le altre
                    }
                }
            }
        } else {
            val cartellaPubblica = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "$SOTTOCARTELLA/$nomeCartella"
            )
            cartellaPubblica.listFiles()?.forEach { file ->
                try {
                    FileInputStream(file).use { input ->
                        zos.putNextEntry(ZipEntry(file.name))
                        input.copyTo(zos)
                        zos.closeEntry()
                    }
                } catch (e: Exception) {
                    // salta questo file
                }
            }
        }
    }

    private fun aggiungiVideoAllozip(context: Context, nomeCartella: String, zos: ZipOutputStream) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_MOVIES}/$SOTTOCARTELLA/$nomeCartella/"
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                arrayOf(relativePath),
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.getString(nameCol)
                    val uri = Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString())
                    try {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            zos.putNextEntry(ZipEntry(displayName))
                            input.copyTo(zos)
                            zos.closeEntry()
                        }
                    } catch (e: Exception) {
                        // salta questo video e continua con gli altri
                    }
                }
            }
        } else {
            val cartellaPubblica = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "$SOTTOCARTELLA/$nomeCartella"
            )
            cartellaPubblica.listFiles()?.forEach { file ->
                try {
                    FileInputStream(file).use { input ->
                        zos.putNextEntry(ZipEntry(file.name))
                        input.copyTo(zos)
                        zos.closeEntry()
                    }
                } catch (e: Exception) {
                    // salta questo file
                }
            }
        }
    }

    private fun aggiungiNotaAllozip(context: Context, nomeCartella: String, zos: ZipOutputStream) {
        val noteFile = File(context.filesDir, "$SOTTOCARTELLA/$nomeCartella/note.txt")
        if (noteFile.exists()) {
            try {
                FileInputStream(noteFile).use { input ->
                    zos.putNextEntry(ZipEntry("$nomeCartella.txt"))
                    input.copyTo(zos)
                    zos.closeEntry()
                }
            } catch (e: Exception) {
                // ignorato
            }
        }
    }
}
