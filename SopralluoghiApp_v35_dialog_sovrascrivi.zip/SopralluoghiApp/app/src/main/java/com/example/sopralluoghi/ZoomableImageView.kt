package com.example.sopralluoghi

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.RectF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.max
import kotlin.math.min

/**
 * ImageView con zoom a pinch (due dita), doppio tocco per ingrandire/rimpicciolire
 * e possibilità di scorrere l'immagine quando è ingrandita.
 *
 * La foto viene sempre mostrata per intero, adattata allo schermo (come faceva
 * "fitCenter"), e SOLO da quel punto di partenza si può ingrandire con le dita.
 */
class ZoomableImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : AppCompatImageView(context, attrs) {

    // Matrice "base": adatta l'immagine intera alla vista (equivalente a fitCenter)
    private val matriceBase = Matrix()
    // Matrice effettivamente applicata (base + zoom/spostamento dell'utente)
    private val matriceCorrente = Matrix()

    private var larghezzaImmagine = 0f
    private var altezzaImmagine = 0f

    private var scalaZoomUtente = 1f
    private val scalaMinima = 1f
    private val scalaMassima = 5f

    private var ultimoX = 0f
    private var ultimoY = 0f
    private var stoSpostando = false

    private val scaleDetector: ScaleGestureDetector
    private val gestureDetector: GestureDetector

    init {
        scaleType = ScaleType.MATRIX
        scaleDetector = ScaleGestureDetector(context, ScaleListener())
        gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (scalaZoomUtente > scalaMinima + 0.1f) {
                    resettaZoom()
                } else {
                    applicaScala(3f, e.x, e.y)
                }
                return true
            }
        })
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        calcolaMatriceBase()
        // Se l'utente non ha ancora ingrandito manualmente, riallinea subito la vista
        // alla posizione corretta (corregge il caso in cui la dimensione reale della
        // vista si stabilizza dopo il primo disegno, mostrando l'immagine più in basso)
        if (scalaZoomUtente <= scalaMinima + 0.01f) {
            resettaZoom()
        }
    }

    /** Imposta la foto e la adatta subito per intero allo schermo, senza zoom residuo */
    fun impostaBitmapEResetZoom(bitmap: Bitmap) {
        larghezzaImmagine = bitmap.width.toFloat()
        altezzaImmagine = bitmap.height.toFloat()
        setImageBitmap(bitmap)
        post {
            calcolaMatriceBase()
            resettaZoom()
        }
    }

    /** Calcola la matrice che mostra l'immagine intera, centrata, adattata alla vista (come fitCenter) */
    private fun calcolaMatriceBase() {
        if (larghezzaImmagine <= 0f || altezzaImmagine <= 0f || width <= 0 || height <= 0) return

        val scala = min(width / larghezzaImmagine, height / altezzaImmagine)
        val dx = (width - larghezzaImmagine * scala) / 2f
        val dy = (height - altezzaImmagine * scala) / 2f

        matriceBase.reset()
        matriceBase.postScale(scala, scala)
        matriceBase.postTranslate(dx, dy)
    }

    private fun resettaZoom() {
        matriceCorrente.set(matriceBase)
        scalaZoomUtente = 1f
        imageMatrix = matriceCorrente
    }

    private fun applicaScala(fattore: Float, focusX: Float, focusY: Float) {
        var nuovaScala = scalaZoomUtente * fattore
        nuovaScala = max(scalaMinima, min(nuovaScala, scalaMassima))
        val fattoreEffettivo = nuovaScala / scalaZoomUtente
        scalaZoomUtente = nuovaScala
        matriceCorrente.postScale(fattoreEffettivo, fattoreEffettivo, focusX, focusY)
        vincolaEntroLimiti()
        imageMatrix = matriceCorrente
    }

    /** Evita che l'immagine venga trascinata troppo fuori dallo schermo */
    private fun vincolaEntroLimiti() {
        if (larghezzaImmagine <= 0f || altezzaImmagine <= 0f) return
        val rect = RectF(0f, 0f, larghezzaImmagine, altezzaImmagine)
        matriceCorrente.mapRect(rect)

        var dx = 0f
        var dy = 0f

        if (rect.width() <= width) {
            dx = (width - rect.width()) / 2f - rect.left
        } else if (rect.left > 0f) {
            dx = -rect.left
        } else if (rect.right < width) {
            dx = width - rect.right
        }

        if (rect.height() <= height) {
            dy = (height - rect.height()) / 2f - rect.top
        } else if (rect.top > 0f) {
            dy = -rect.top
        } else if (rect.bottom < height) {
            dy = height - rect.bottom
        }

        matriceCorrente.postTranslate(dx, dy)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                ultimoX = event.x
                ultimoY = event.y
                stoSpostando = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (stoSpostando && scalaZoomUtente > scalaMinima && !scaleDetector.isInProgress) {
                    val dx = event.x - ultimoX
                    val dy = event.y - ultimoY
                    matriceCorrente.postTranslate(dx, dy)
                    vincolaEntroLimiti()
                    imageMatrix = matriceCorrente
                    ultimoX = event.x
                    ultimoY = event.y
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                stoSpostando = false
            }
        }
        parent?.requestDisallowInterceptTouchEvent(scalaZoomUtente > scalaMinima || scaleDetector.isInProgress)
        return true
    }

    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            applicaScala(detector.scaleFactor, detector.focusX, detector.focusY)
            return true
        }
    }
}
