package com.example.sopralluoghi

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import android.widget.VideoView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.io.File

class FullImageActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_INDICE = "EXTRA_INDICE"
        const val EXTRA_ELIMINATO = "EXTRA_ELIMINATO"
    }

    private val elementi = mutableListOf<FotoItem>()
    private lateinit var pager: ViewPager2
    private lateinit var adapter: ElementoPagerAdapter
    private lateinit var tvPosizione: TextViewSicuro

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_full_image)

        elementi.addAll(GalleriaCorrente.elementi)
        val indiceIniziale = intent.getIntExtra(EXTRA_INDICE, 0).coerceIn(0, (elementi.size - 1).coerceAtLeast(0))

        if (elementi.isEmpty()) {
            Toast.makeText(this, "Nessun elemento da mostrare", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        pager = findViewById(R.id.pagerElementi)
        tvPosizione = TextViewSicuro(findViewById(R.id.tvPosizionePager))

        adapter = ElementoPagerAdapter(elementi)
        pager.adapter = adapter
        pager.setCurrentItem(indiceIniziale, false)

        aggiornaContatore(indiceIniziale)

        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                aggiornaContatore(position)
                gestisciCambioPagina(position)
            }
        })

        findViewById<View>(R.id.btnEliminaFoto).setOnClickListener { confermaEliminazione() }
    }

    private fun aggiornaContatore(posizione: Int) {
        tvPosizione.testo("${posizione + 1} / ${elementi.size}")
    }

    /** Ferma il video della pagina precedente e avvia quello della pagina corrente, se è un video */
    private fun gestisciCambioPagina(nuovaPosizione: Int) {
        val recyclerInterno = pager.getChildAt(0) as? RecyclerView ?: return
        for (i in elementi.indices) {
            val holder = recyclerInterno.findViewHolderForAdapterPosition(i) as? ElementoPagerAdapter.PagerViewHolder
            if (holder != null && i != nuovaPosizione && holder.video.isPlaying) {
                holder.video.pause()
            }
        }
        val holderCorrente = recyclerInterno.findViewHolderForAdapterPosition(nuovaPosizione) as? ElementoPagerAdapter.PagerViewHolder
        if (holderCorrente != null && elementi[nuovaPosizione].isVideo) {
            holderCorrente.video.start()
        }
    }

    private fun confermaEliminazione() {
        val posizione = pager.currentItem
        val nome = elementi[posizione].nomeVisualizzato
        AlertDialog.Builder(this)
            .setTitle("Eliminare questo elemento?")
            .setMessage("$nome verrà eliminato definitivamente.")
            .setPositiveButton("Elimina") { _, _ -> eliminaElemento(posizione) }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun eliminaElemento(posizione: Int) {
        val item = elementi[posizione]
        try {
            if (item.uri != null) {
                contentResolver.delete(item.uri, null, null)
            } else if (item.file != null) {
                item.file.delete()
            }
            Toast.makeText(this, "Elemento eliminato", Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK, android.content.Intent().putExtra(EXTRA_ELIMINATO, true))

            elementi.removeAt(posizione)
            GalleriaCorrente.elementi = elementi.toList()

            if (elementi.isEmpty()) {
                finish()
                return
            }
            adapter.notifyItemRemoved(posizione)
            val nuovaPosizione = posizione.coerceAtMost(elementi.size - 1)
            pager.setCurrentItem(nuovaPosizione, false)
            aggiornaContatore(nuovaPosizione)
        } catch (e: Exception) {
            Toast.makeText(this, "Errore durante l'eliminazione: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /** Piccolo wrapper per evitare ripetizioni nell'aggiornare il contatore "3 / 12" */
    private class TextViewSicuro(private val view: android.widget.TextView) {
        fun testo(s: String) {
            view.text = s
        }
    }
}

/** Adapter del pager: ogni pagina mostra una foto (con zoom) oppure un video */
class ElementoPagerAdapter(
    private val elementi: List<FotoItem>
) : RecyclerView.Adapter<ElementoPagerAdapter.PagerViewHolder>() {

    inner class PagerViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val iv: ZoomableImageView = view.findViewById(R.id.ivFotoPager)
        val video: VideoView = view.findViewById(R.id.videoPager)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PagerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_pager_elemento, parent, false)
        return PagerViewHolder(view)
    }

    override fun onBindViewHolder(holder: PagerViewHolder, position: Int) {
        val item = elementi[position]
        val context = holder.itemView.context

        if (item.isVideo) {
            holder.iv.visibility = View.GONE
            holder.video.visibility = View.VISIBLE

            val uriDaRiprodurre = item.uri ?: item.file?.let {
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", it)
            }
            if (uriDaRiprodurre != null) {
                holder.video.setVideoURI(uriDaRiprodurre)
                holder.video.setOnPreparedListener { mp ->
                    mp.isLooping = true
                    holder.video.start()
                }
                holder.video.setOnErrorListener { _, _, _ ->
                    Toast.makeText(context, "Impossibile riprodurre il video", Toast.LENGTH_SHORT).show()
                    true
                }
            }
        } else {
            holder.video.visibility = View.GONE
            holder.iv.visibility = View.VISIBLE

            Thread {
                val filePathObj = item.file
                val bitmap = ImmagineUtils.caricaBitmapCorretto(context, item.uri, filePathObj, inSampleSize = 1)
                holder.itemView.post {
                    if (bitmap != null) {
                        holder.iv.impostaBitmapEResetZoom(bitmap)
                    } else {
                        Toast.makeText(context, "Impossibile aprire la foto", Toast.LENGTH_SHORT).show()
                    }
                }
            }.start()
        }
    }

    override fun onViewRecycled(holder: PagerViewHolder) {
        super.onViewRecycled(holder)
        if (holder.video.isPlaying) {
            holder.video.stopPlayback()
        }
    }

    override fun getItemCount(): Int = elementi.size
}
