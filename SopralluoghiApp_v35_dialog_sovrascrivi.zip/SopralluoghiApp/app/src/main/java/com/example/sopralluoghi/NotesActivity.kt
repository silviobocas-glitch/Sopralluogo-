package com.example.sopralluoghi

import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class NotesActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NOME = "NOME_CARTELLA"
        private const val SOTTOCARTELLA = "Sopralluoghi"
    }

    private lateinit var nomeCartella: String
    private lateinit var etNote: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notes)

        nomeCartella = intent.getStringExtra(EXTRA_NOME) ?: run {
            finish()
            return
        }

        findViewById<TextView>(R.id.tvTitoloNote).text = "Note — $nomeCartella"
        etNote = findViewById(R.id.etNote)
        etNote.setText(leggiNota())
    }

    override fun onPause() {
        super.onPause()
        salvaNota()
    }

    private fun fileNota(): File {
        val cartella = File(filesDir, "$SOTTOCARTELLA/$nomeCartella")
        if (!cartella.exists()) cartella.mkdirs()
        return File(cartella, "note.txt")
    }

    private fun leggiNota(): String {
        return try {
            val file = fileNota()
            if (file.exists()) file.readText() else ""
        } catch (e: Exception) {
            ""
        }
    }

    private fun salvaNota() {
        try {
            fileNota().writeText(etNote.text.toString())
        } catch (e: Exception) {
            // se il salvataggio fallisce non blocchiamo l'uscita dalla schermata
        }
    }
}
