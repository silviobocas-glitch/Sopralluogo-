package com.example.sopralluoghi

import android.content.Context
import android.graphics.Matrix
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.max
import kotlin.math.min

/**
 * ImageView con zoom a pinch (due dita), doppio tocco per ingrandire/rimpicciolire
 * e possibilità di scorrere l'immagine quando è ingrandita.
 */
class ZoomableImageView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : AppCompatImageView(context, attrs) {

    private val matriceImmagine = Matrix()
    private var scalaCorrente = 1f
    private val scalaMinima = 1f
    private val scalaMassima = 5f

    private var ultimoX = 0f
    private var ultimoY = 0f
    private var stoSpostando = false

    private val scaleDetector: ScaleGestureDetector
    private val gestureDetector: GestureDetector

    init {
        scaleType = ScaleType.MATRIX
        scaleDetector = ScaleGestureDetector(context, ScaleListener())
        gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                // Doppio tocco: alterna tra dimensione normale e zoom 3x
                if (scalaCorrente > scalaMinima + 0.1f) {
                    resettaZoom()
                } else {
                    matriceImmagine.postScale(3f, 3f, e.x, e.y)
                    scalaCorrente = 3f
                    imageMatrix = matriceImmagine
                }
                return true
            }
        })
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                ultimoX = event.x
                ultimoY = event.y
                stoSpostando = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (stoSpostando && scalaCorrente > scalaMinima && !scaleDetector.isInProgress) {
                    val dx = event.x - ultimoX
                    val dy = event.y - ultimoY
                    matriceImmagine.postTranslate(dx, dy)
                    imageMatrix = matriceImmagine
                    ultimoX = event.x
                    ultimoY = event.y
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                stoSpostando = false
            }
        }
        // Richiediamo sempre al genitore di non intercettare il touch mentre siamo zoomati o stiamo zoomando
        parent?.requestDisallowInterceptTouchEvent(scalaCorrente > scalaMinima || scaleDetector.isInProgress)
        return true
    }

    private fun resettaZoom() {
        matriceImmagine.reset()
        scalaCorrente = 1f
        imageMatrix = matriceImmagine
    }

    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            var nuovaScala = scalaCorrente * detector.scaleFactor
            nuovaScala = max(scalaMinima, min(nuovaScala, scalaMassima))
            val fattoreEffettivo = nuovaScala / scalaCorrente
            scalaCorrente = nuovaScala
            matriceImmagine.postScale(fattoreEffettivo, fattoreEffettivo, detector.focusX, detector.focusY)
            imageMatrix = matriceImmagine
            return true
        }
    }

    /** Da chiamare quando si carica una nuova immagine, per ripartire senza zoom residuo */
    fun impostaBitmapEResetZoom(bitmap: android.graphics.Bitmap) {
        setImageBitmap(bitmap)
        post { resettaZoom() }
    }
}
