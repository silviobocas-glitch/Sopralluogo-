package com.example.sopralluoghi

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.InputType
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale

class CameraActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NOME_SOPRALLUOGO = "NOME_SOPRALLUOGO"
        private const val SOTTOCARTELLA = "Sopralluoghi"

        // --- Impostazioni versione di prova ---
        private const val PREFS_TRIAL = "trial_prefs"
        private const val KEY_FOTO_TOTALI = "foto_totali_scattate"
        private const val KEY_SBLOCCATO = "app_sbloccata"
        private const val LIMITE_FOTO_PROVA = 3
        private const val CODICE_SBLOCCO = "Bic26"
    }

    private lateinit var imageCapture: ImageCapture
    private lateinit var nomeCartella: String
    private var contatore = 0

    private lateinit var trialPrefs: android.content.SharedPreferences
    private var appSbloccata = false
    private var fotoTotaliScattate = 0

    private var camera: Camera? = null
    private var torciaAccesa = false

    // Riferimento all'ultima foto scattata, per poterla eliminare
    private var ultimoUri: Uri? = null
    private var ultimoFile: File? = null

    private lateinit var tvContatore: TextView
    private lateinit var tvZoom: TextView
    private lateinit var btnTorcia: TextView
    private lateinit var frameMiniatura: FrameLayout
    private lateinit var ivMiniatura: ImageView

    private val scaleGestureDetector by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val cam = camera ?: return true
                val zoomAttuale = cam.cameraInfo.zoomState.value?.zoomRatio ?: 1f
                val nuovoZoom = zoomAttuale * detector.scaleFactor
                cam.cameraControl.setZoomRatio(nuovoZoom)
                return true
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_camera)

        nomeCartella = intent.getStringExtra(EXTRA_NOME_SOPRALLUOGO) ?: "Sopralluogo"

        trialPrefs = getSharedPreferences(PREFS_TRIAL, Context.MODE_PRIVATE)
        appSbloccata = trialPrefs.getBoolean(KEY_SBLOCCATO, false)
        fotoTotaliScattate = trialPrefs.getInt(KEY_FOTO_TOTALI, 0)

        findViewById<TextView>(R.id.tvNomeCartella).text = nomeCartella
        tvContatore = findViewById(R.id.tvContatore)
        tvZoom = findViewById(R.id.tvZoom)
        btnTorcia = findViewById(R.id.btnTorcia)
        frameMiniatura = findViewById(R.id.frameMiniatura)
        ivMiniatura = findViewById(R.id.ivMiniatura)

        contatore = contaFotoEsistenti()
        aggiornaTestoContatore()

        avviaAnteprimaFotocamera()

        findViewById<Button>(R.id.btnScatta).setOnClickListener { scattaFoto() }
        findViewById<Button>(R.id.btnFine).setOnClickListener { finish() }
        btnTorcia.setOnClickListener { attivaDisattivaTorcia() }
        findViewById<TextView>(R.id.btnCancellaUltima).setOnClickListener { eliminaUltimaFoto() }
    }

    private fun avviaAnteprimaFotocamera() {
        val previewView = findViewById<PreviewView>(R.id.previewView)
        previewView.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            true
        }

        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .setTargetRotation(Surface.ROTATION_0)
                .build()

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                camera = cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture)
                camera?.cameraInfo?.zoomState?.observe(this) { zoomState ->
                    tvZoom.text = String.format(Locale.ITALY, "%.1fx", zoomState.zoomRatio)
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Errore avvio fotocamera: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun attivaDisattivaTorcia() {
        val cam = camera ?: return
        if (!cam.cameraInfo.hasFlashUnit()) {
            Toast.makeText(this, "Questo dispositivo non ha una torcia", Toast.LENGTH_SHORT).show()
            return
        }
        torciaAccesa = !torciaAccesa
        cam.cameraControl.enableTorch(torciaAccesa)
        btnTorcia.text = if (torciaAccesa) "⚡ ON" else "⚡"
    }

    private fun scattaFoto() {
        if (!appSbloccata && fotoTotaliScattate >= LIMITE_FOTO_PROVA) {
            mostraDialogSblocco()
            return
        }

        val prossimoNumero = contatore + 1
        val nomeFile = "$nomeCartella $prossimoNumero"

        var fileLegacyTemp: File? = null

        val outputOptions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            creaOutputOptionsMediaStore(nomeFile)
        } else {
            val file = costruisciFileLegacy(nomeFile)
            fileLegacyTemp = file
            ImageCapture.OutputFileOptions.Builder(file).build()
        }

        imageCapture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    contatore = prossimoNumero
                    aggiornaTestoContatore()

                    ultimoUri = output.savedUri
                    ultimoFile = fileLegacyTemp
                    mostraMiniatura(ultimoUri, ultimoFile)

                    if (!appSbloccata) {
                        fotoTotaliScattate += 1
                        trialPrefs.edit().putInt(KEY_FOTO_TOTALI, fotoTotaliScattate).apply()

                        val rimanenti = LIMITE_FOTO_PROVA - fotoTotaliScattate
                        if (rimanenti > 0) {
                            Toast.makeText(
                                this@CameraActivity,
                                "Salvata: $nomeFile — foto della versione trial rimaste: $rimanenti",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                this@CameraActivity,
                                "Salvata: $nomeFile — hai raggiunto il limite della versione trial",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    } else {
                        Toast.makeText(this@CameraActivity, "Salvata: $nomeFile", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onError(exc: ImageCaptureException) {
                    Toast.makeText(
                        this@CameraActivity,
                        "Errore salvataggio foto: ${exc.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        )
    }

    /** Android 10+ (API 29+): salva tramite MediaStore, visibile subito in Galleria */
    private fun creaOutputOptionsMediaStore(nomeFile: String): ImageCapture.OutputFileOptions {
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, nomeFile)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(
                MediaStore.MediaColumns.RELATIVE_PATH,
                "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella"
            )
        }
        return ImageCapture.OutputFileOptions.Builder(
            contentResolver,
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            contentValues
        ).build()
    }

    /** Android 9 e precedenti: scrive direttamente nella cartella pubblica Pictures */
    private fun costruisciFileLegacy(nomeFile: String): File {
        val cartellaPubblica = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            "$SOTTOCARTELLA/$nomeCartella"
        )
        if (!cartellaPubblica.exists()) {
            cartellaPubblica.mkdirs()
        }
        return File(cartellaPubblica, "$nomeFile.jpg")
    }

    /** Mostra un dialog che chiede il codice per sbloccare l'app oltre il limite di prova */
    private fun mostraDialogSblocco() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            hint = "Inserisci il codice"
        }

        AlertDialog.Builder(this)
            .setTitle("Versione trial terminata")
            .setMessage("Hai raggiunto il limite di $LIMITE_FOTO_PROVA foto gratuite. Inserisci il codice per continuare a usare l'app.")
            .setView(input)
            .setPositiveButton("Sblocca") { _, _ ->
                val codiceInserito = input.text.toString().trim()
                if (codiceInserito.equals(CODICE_SBLOCCO, ignoreCase = false)) {
                    appSbloccata = true
                    trialPrefs.edit().putBoolean(KEY_SBLOCCATO, true).apply()
                    Toast.makeText(this, "App sbloccata, buon lavoro!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Codice errato", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Annulla", null)
            .setCancelable(false)
            .show()
    }

    /** Carica una miniatura ridotta della foto appena scattata, in background */
    private fun mostraMiniatura(uri: Uri?, file: File?) {
        Thread {
            val bitmap = ImmagineUtils.caricaBitmapCorretto(this, uri, file, inSampleSize = 4)

            runOnUiThread {
                if (bitmap != null) {
                    ivMiniatura.setImageBitmap(bitmap)
                    frameMiniatura.visibility = View.VISIBLE
                }
            }
        }.start()
    }

    /** Elimina l'ultima foto scattata e fa tornare indietro la numerazione di uno */
    private fun eliminaUltimaFoto() {
        try {
            if (ultimoUri != null) {
                contentResolver.delete(ultimoUri!!, null, null)
            } else if (ultimoFile != null) {
                ultimoFile!!.delete()
            } else {
                return
            }
            contatore -= 1
            aggiornaTestoContatore()
            ivMiniatura.setImageDrawable(null)
            frameMiniatura.visibility = View.GONE
            ultimoUri = null
            ultimoFile = null
            Toast.makeText(this, "Ultima foto eliminata", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Errore durante l'eliminazione: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Conta quante foto esistono già per questo nome di sopralluogo,
     * cosi se l'utente chiude e riapre l'app la numerazione prosegue
     * (es. Castano 1, Castano 2 ... invece di ripartire da 1).
     */
    private fun contaFotoEsistenti(): Int {
        var massimo = 0
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val relativePath = "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella/"
                val projection = arrayOf(MediaStore.MediaColumns.DISPLAY_NAME)
                val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
                val selectionArgs = arrayOf(relativePath)
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    selection,
                    selectionArgs,
                    null
                )?.use { cursor ->
                    val colonnaNome = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                    while (cursor.moveToNext()) {
                        val nomeCompleto = cursor.getString(colonnaNome)
                        estraiNumero(nomeCompleto)?.let { if (it > massimo) massimo = it }
                    }
                }
            } else {
                val cartellaPubblica = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "$SOTTOCARTELLA/$nomeCartella"
                )
                cartellaPubblica.listFiles()?.forEach { file ->
                    estraiNumero(file.name)?.let { if (it > massimo) massimo = it }
                }
            }
        } catch (e: Exception) {
            // Se la query fallisce, si riparte semplicemente da 1
        }
        return massimo
    }

    private fun estraiNumero(nomeFile: String): Int? {
        val senzaEstensione = nomeFile.substringBeforeLast(".")
        val prefisso = "$nomeCartella "
        if (!senzaEstensione.startsWith(prefisso)) return null
        return senzaEstensione.removePrefix(prefisso).toIntOrNull()
    }

    private fun aggiornaTestoContatore() {
        tvContatore.text = "Foto: $contatore"
    }
}
