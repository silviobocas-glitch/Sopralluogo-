# Regole ProGuard/R8 per Sopralluoghi

# CameraX usa alcune classi via reflection: le manteniamo per sicurezza
-keep class androidx.camera.** { *; }
-dontwarn androidx.camera.**

# AndroidX Exif
-keep class androidx.exifinterface.** { *; }

# Evita di rimuovere le annotazioni necessarie a Parcelable/Serializable custom
-keepclassmembers class * implements android.os.Parcelable {
    public static final ** CREATOR;
}

# Mantieni i nomi dei metodi nativi (se presenti)
-keepclasseswithmembernames class * {
    native <methods>;
}

# View binding
-keep class com.example.sopralluoghi.databinding.** { *; }
