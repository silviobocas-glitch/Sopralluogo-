package com.example.sopralluoghi

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * Anello che circonda il pulsante di scatto durante la registrazione video e si "consuma" in
 * senso orario, partendo dall'alto come le lancette di un orologio: dà un riferimento visivo
 * immediato del tempo che resta, in accompagnamento al conto alla rovescia numerico dei 40
 * secondi mostrato dentro al pulsante rosso.
 */
class AnelloTimerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Tempo rimanente in percentuale: 1f = appena partito, 0f = tempo scaduto */
    var progresso: Float = 1f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }

    private val larghezzaTratto = dpToPx(4f)

    /** Quadrante di sfondo: cerchio sottile e semi-trasparente, sempre visibile per intero */
    private val paintSfondo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = larghezzaTratto
        color = Color.parseColor("#40FFFFFF")
    }

    /** Arco che si accorcia col passare del tempo, come le lancette di un orologio */
    private val paintProgresso = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = larghezzaTratto
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#FFFFFFFF")
    }

    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val meta = larghezzaTratto / 2f
        rect.set(meta, meta, width - meta, height - meta)

        canvas.drawOval(rect, paintSfondo)

        // Parte dalle ore 12 (-90°) e scende in senso orario in proporzione al tempo rimasto
        val angoloSweep = 360f * progresso
        if (angoloSweep > 0f) {
            canvas.drawArc(rect, -90f, angoloSweep, false, paintProgresso)
        }
    }

    private fun dpToPx(dp: Float): Float = dp * resources.displayMetrics.density
}
