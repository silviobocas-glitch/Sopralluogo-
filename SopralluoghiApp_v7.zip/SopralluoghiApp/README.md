# Sopralluoghi — App Android

App per i sopralluoghi, organizzata per cartelle:

1. **Home**: vedi l'elenco dei sopralluoghi già fatti, più una cartella tratteggiata **"➕ Nuovo sopralluogo"**.
2. Tocca "Nuovo sopralluogo", scrivi un nome (es. "Castano") → si apre la cartella appena creata.
3. Dentro la cartella hai 4 pulsanti:
   - **📷 Fotocamera** — scatta foto numerate in progressione (Castano 1, Castano 2...), con zoom (pizzica lo schermo), torcia e anteprima ultima foto.
   - **🖼 Vedi foto** — galleria a griglia con TUTTE le foto di questo sopralluogo, dentro l'app (non serve aprire la Galleria di sistema). Tocca una foto per vederla a schermo intero, con possibilità di eliminarla.
   - **📝 Note** — un blocco note testuale legato a questo sopralluogo (si salva da solo quando esci).
   - **📤 Condividi (mail / WhatsApp)** — crea uno zip con tutte le foto + le note di questo sopralluogo e apre il menu di condivisione di Android: scegli Gmail, WhatsApp, Drive, ecc.
4. Premi "← Indietro" per tornare alla Home e creare un altro sopralluogo, oppure riaprire uno di quelli già fatti.
5. Tenendo premuto (long-press) su una cartella nella Home, puoi anche **condividerla** o **eliminarla** direttamente, senza aprirla.

Le foto restano comunque visibili anche in Galleria (Pictures/Sopralluoghi/NomeCartella), ma non serve più uscire dall'app per vederle.



## Come compilare l'APK SENZA installare nulla (anche da cellulare)

Se non puoi installare Android Studio (es. PC aziendale) o vuoi farlo direttamente dal telefono, puoi far compilare l'app **gratis nel cloud** usando GitHub. Basta caricare UN SOLO file (questo zip), niente cartelle da trascinare.

1. Vai su **github.com** dal browser, crea un account gratuito se non ne hai già uno.
2. Crea un nuovo repository (es. "sopralluoghi-app", può essere privato).
3. **Add file → Upload files** → seleziona questo file `SopralluoghiApp.zip` così com'è (senza estrarlo) → **Commit changes**.
4. **Add file → Create new file** → nel campo del nome scrivi `.github/workflows/build.yml` (GitHub crea da solo le cartelle) → incolla questo contenuto:

```yaml
name: Compila APK Sopralluoghi

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Scarica il codice
        uses: actions/checkout@v4

      - name: Estrai il progetto dallo zip
        run: unzip -o SopralluoghiApp.zip

      - name: Installa Java
        uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'

      - name: Installa Android SDK
        uses: android-actions/setup-android@v3

      - name: Compila APK (debug)
        run: |
          cd SopralluoghiApp
          gradle assembleDebug --no-daemon

      - name: Carica APK come risultato
        uses: actions/upload-artifact@v4
        with:
          name: sopralluoghi-apk
          path: SopralluoghiApp/app/build/outputs/apk/debug/app-debug.apk
```

   → **Commit changes**.
5. Vai sulla scheda **Actions**: la compilazione parte da sola e impiega 3-5 minuti.
6. Quando è completata (segno verde), apri il workflow → in fondo, sotto **Artifacts**, scarica `sopralluoghi-apk` (è uno zip che contiene `app-debug.apk`). Estrailo con l'app Files del telefono.
7. Apri `app-debug.apk`: il telefono chiederà di autorizzare "fonte sconosciuta" solo per quel file (impostazione del telefono, non del PC) → installa.

## Come compilare con Android Studio (se puoi installare programmi)

1. Installa **Android Studio** (gratuito): https://developer.android.com/studio
2. Apri Android Studio → **Open** → seleziona la cartella `SopralluoghiApp` (questa cartella).
3. Al primo avvio, Android Studio scaricherà da solo il Gradle Wrapper e le dipendenze (serve una connessione internet la prima volta). Lascia fare il sync automatico.
4. Collega il telefono Android via USB con il **debug USB attivo** (Impostazioni → Opzioni sviluppatore → Debug USB), oppure usa un emulatore.
5. Premi il tasto verde **Run ▶** in alto: l'app verrà installata e avviata sul telefono.

## Requisiti

- Android 7.0 (API 24) o superiore.
- Permesso fotocamera (richiesto automaticamente al primo avvio).

## Personalizzazioni facili

- **Cartella principale**: nel file `CameraActivity.kt` puoi cambiare `SOTTOCARTELLA = "Sopralluoghi"` con un altro nome.
- **Formato nome foto**: nella funzione `scattaFoto()`, la riga `val nomeFile = "$nomeCartella $prossimoNumero"` genera nomi tipo "Castano 1". Puoi cambiarla, ad esempio in `"$nomeCartella-$prossimoNumero"` per ottenere "Castano-1".
- **Icona dell'app**: al momento usa l'icona di default di Android. Per metterne una tua, in Android Studio fai clic destro su `res` → **New → Image Asset** e segui la procedura guidata.
