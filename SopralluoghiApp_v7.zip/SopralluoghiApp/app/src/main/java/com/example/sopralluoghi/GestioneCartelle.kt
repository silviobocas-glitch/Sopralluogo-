package com.example.sopralluoghi

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** Salva l'elenco dei sopralluoghi creati (nomi cartella) nelle SharedPreferences */
object PrefsHelper {
    private const val PREFS = "sopralluoghi_prefs"
    private const val KEY_LISTA = "lista_nomi"
    private const val SEPARATORE = "\u0001"

    fun getLista(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LISTA, "") ?: ""
        return if (raw.isEmpty()) emptyList() else raw.split(SEPARATORE)
    }

    /** Aggiunge il nome in cima alla lista (più recente prima). Se esiste già, lo sposta in cima. */
    fun aggiungiOSpostaInCima(context: Context, nome: String) {
        val lista = getLista(context).toMutableList()
        lista.remove(nome)
        lista.add(0, nome)
        salvaLista(context, lista)
    }

    fun rimuovi(context: Context, nome: String) {
        val lista = getLista(context).toMutableList()
        lista.remove(nome)
        salvaLista(context, lista)
    }

    private fun salvaLista(context: Context, lista: List<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_LISTA, lista.joinToString(SEPARATORE))
            .apply()
    }
}

/** Elimina definitivamente foto, note e riferimenti di un sopralluogo */
object GestioneCartelle {
    private const val SOTTOCARTELLA = "Sopralluoghi"

    fun eliminaTutto(context: Context, nomeCartella: String) {
        // Elimina le foto
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val relativePath = "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella/"
                context.contentResolver.delete(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    "${MediaStore.MediaColumns.RELATIVE_PATH} = ?",
                    arrayOf(relativePath)
                )
            } else {
                val cartellaPubblica = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "$SOTTOCARTELLA/$nomeCartella"
                )
                cartellaPubblica.deleteRecursively()
            }
        } catch (e: Exception) {
            // proseguiamo comunque con l'eliminazione delle note
        }

        // Elimina le note (archiviazione interna dell'app)
        try {
            File(context.filesDir, "$SOTTOCARTELLA/$nomeCartella").deleteRecursively()
        } catch (e: Exception) {
            // ignorato
        }
    }
}
