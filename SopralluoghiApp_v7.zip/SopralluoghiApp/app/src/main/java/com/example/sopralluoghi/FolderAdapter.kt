package com.example.sopralluoghi

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class FolderAdapter(
    private val elenco: List<String>,
    private val onNuovo: () -> Unit,
    private val onApri: (String) -> Unit,
    private val onLongClick: (String) -> Unit
) : RecyclerView.Adapter<FolderAdapter.TileViewHolder>() {

    class TileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val root: View = itemView.findViewById(R.id.rootTile)
        val icona: TextView = itemView.findViewById(R.id.tvIconaCartella)
        val nome: TextView = itemView.findViewById(R.id.tvNomeCartella)
        val sottotitolo: TextView = itemView.findViewById(R.id.tvSottotitoloCartella)
        val chevron: TextView = itemView.findViewById(R.id.tvChevronCartella)
    }

    override fun getItemCount(): Int = elenco.size + 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TileViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_folder_tile, parent, false)
        return TileViewHolder(view)
    }

    override fun onBindViewHolder(holder: TileViewHolder, position: Int) {
        val context = holder.itemView.context
        if (position == 0) {
            // Prima cella: tratteggiata e bianca, per creare un nuovo sopralluogo
            holder.root.setBackgroundResource(R.drawable.bg_new_folder)
            holder.icona.background = ContextCompat.getDrawable(context, R.drawable.bg_icon_badge_blu_chiaro)
            holder.icona.text = "➕"
            holder.icona.setTextColor(ContextCompat.getColor(context, R.color.colore_cartella_blu))
            holder.nome.text = "Nuovo sopralluogo"
            holder.nome.setTextColor(ContextCompat.getColor(context, R.color.colore_testo_scuro))
            holder.sottotitolo.text = "Tocca per iniziare"
            holder.sottotitolo.setTextColor(ContextCompat.getColor(context, R.color.colore_testo_grigio))
            holder.chevron.visibility = View.GONE
            holder.itemView.setOnClickListener { onNuovo() }
            holder.itemView.setOnLongClickListener(null)
            holder.itemView.isLongClickable = false
        } else {
            val nome = elenco[position - 1]
            holder.root.setBackgroundResource(R.drawable.bg_folder)
            holder.icona.background = ContextCompat.getDrawable(context, R.drawable.bg_icon_badge_white)
            holder.icona.text = "📁"
            holder.icona.setTextColor(ContextCompat.getColor(context, android.R.color.black))
            holder.nome.text = nome
            holder.nome.setTextColor(ContextCompat.getColor(context, android.R.color.white))
            holder.sottotitolo.text = "Tocca per aprire"
            holder.sottotitolo.setTextColor(0xCCFFFFFF.toInt())
            holder.chevron.visibility = View.VISIBLE
            holder.itemView.setOnClickListener { onApri(nome) }
            holder.itemView.setOnLongClickListener {
                onLongClick(nome)
                true
            }
        }
    }
}
