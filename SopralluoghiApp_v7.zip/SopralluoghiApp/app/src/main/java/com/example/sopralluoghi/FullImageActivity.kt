package com.example.sopralluoghi

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class FullImageActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URI = "EXTRA_URI"
        const val EXTRA_FILE_PATH = "EXTRA_FILE_PATH"
        const val EXTRA_NOME = "EXTRA_NOME"
    }

    private var uri: Uri? = null
    private var filePath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_full_image)

        uri = intent.getParcelableExtra(EXTRA_URI)
        filePath = intent.getStringExtra(EXTRA_FILE_PATH)
        val nome = intent.getStringExtra(EXTRA_NOME) ?: ""

        val iv = findViewById<ZoomableImageView>(R.id.ivFotoIntera)
        findViewById<TextView>(R.id.btnIndietroFull).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnEliminaFoto).setOnClickListener { confermaEliminazione(nome) }

        Thread {
            val filePathObj = filePath?.let { File(it) }
            val bitmap = ImmagineUtils.caricaBitmapCorretto(this, uri, filePathObj, inSampleSize = 1)
            runOnUiThread {
                if (bitmap != null) {
                    iv.impostaBitmapEResetZoom(bitmap)
                } else {
                    Toast.makeText(this, "Impossibile aprire la foto", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun confermaEliminazione(nome: String) {
        AlertDialog.Builder(this)
            .setTitle("Eliminare questa foto?")
            .setMessage("$nome verrà eliminata definitivamente.")
            .setPositiveButton("Elimina") { _, _ -> eliminaFoto() }
            .setNegativeButton("Annulla", null)
            .show()
    }

    private fun eliminaFoto() {
        try {
            if (uri != null) {
                contentResolver.delete(uri!!, null, null)
            } else if (filePath != null) {
                File(filePath!!).delete()
            }
            Toast.makeText(this, "Foto eliminata", Toast.LENGTH_SHORT).show()
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Errore durante l'eliminazione: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
