package com.example.sopralluoghi

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/**
 * Controlla che l'APK in esecuzione sia stato firmato con la chiave originale.
 *
 * Se qualcuno decompila l'app, la modifica (es. rimuove il controllo del codice
 * di sblocco Bic26) e prova a ridistribuirla, sarà OBBLIGATO a firmarla con una
 * chiave diversa dalla propria: in quel caso questo controllo lo rileva e
 * l'app si rifiuta di funzionare.
 *
 * IMPORTANTE: funziona solo sulle build "release" firmate con il keystore
 * definitivo. Sulle build "debug" (chiave temporanea) il controllo è
 * disattivato automaticamente, altrimenti non funzionerebbe mai in sviluppo.
 */
object VerificaFirma {

    // Impronta SHA-256 del certificato di firma ufficiale dell'app.
    // NON cambiare questo valore a meno di aver rigenerato il keystore.
    private const val IMPRONTA_ATTESA =
        "28D415F13EC1AC35E0AC6416EC6E4EFE5CDFF49D148D4B004F12115D9E780D16"

    /** true = firma valida (o build debug, in cui il controllo non si applica) */
    fun firmaValida(context: Context): Boolean {
        // In debug (build di sviluppo) non blocchiamo mai: la chiave debug cambia ad ogni build.
        if (isDebugBuild(context)) return true

        val impronteTrovate = ottieniImproteSHA256(context)
        if (impronteTrovate.isEmpty()) return false

        return impronteTrovate.any { it.equals(IMPRONTA_ATTESA, ignoreCase = true) }
    }

    private fun isDebugBuild(context: Context): Boolean {
        return (context.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0
    }

    private fun ottieniImproteSHA256(context: Context): List<String> {
        val risultati = mutableListOf<String>()
        try {
            val pm = context.packageManager
            val pacchetto = context.packageName

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(pacchetto, PackageManager.GET_SIGNING_CERTIFICATES)
                val firme = info.signingInfo?.let {
                    if (it.hasMultipleSigners()) it.apkContentsSigners else it.signingCertificateHistory
                } ?: emptyArray()
                for (firma in firme) {
                    risultati.add(sha256Esadecimale(firma.toByteArray()))
                }
            } else {
                @Suppress("DEPRECATION")
                val info = pm.getPackageInfo(pacchetto, PackageManager.GET_SIGNATURES)
                @Suppress("DEPRECATION")
                val firme = info.signatures ?: emptyArray()
                for (firma in firme) {
                    risultati.add(sha256Esadecimale(firma.toByteArray()))
                }
            }
        } catch (e: Exception) {
            // In caso di errore consideriamo la firma non valida
        }
        return risultati
    }

    private fun sha256Esadecimale(dati: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(dati)
        return digest.joinToString("") { "%02X".format(it) }
    }
}
