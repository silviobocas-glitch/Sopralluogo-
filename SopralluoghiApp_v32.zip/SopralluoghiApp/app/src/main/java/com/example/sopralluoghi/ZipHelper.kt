package com.example.sopralluoghi

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ZipHelper {
    private const val SOTTOCARTELLA = "Sopralluoghi"
    private const val CARTELLA_DOCUMENTI = "Documenti"

    /** Crea uno zip (in cache) con tutte le foto e la nota del sopralluogo. Ritorna null in caso di errore. */
    fun creaZipDiCartella(context: Context, nomeCartella: String): File? {
        return try {
            val zipFile = File(context.cacheDir, "$nomeCartella.zip")
            if (zipFile.exists()) zipFile.delete()

            ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
                aggiungiFotoAllozip(context, nomeCartella, zos)
                aggiungiVideoAllozip(context, nomeCartella, zos)
                aggiungiNotaAllozip(context, nomeCartella, zos)
            }
            zipFile
        } catch (e: Exception) {
            null
        }
    }

    /** Vero se esiste già uno zip con questo nome nella cartella "Documenti" del dispositivo */
    fun esisteZipInDocumenti(context: Context, nomeCartella: String): Boolean {
        val nomeFile = "$nomeCartella.zip"
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            esisteInMediaStore(context, nomeFile)
        } else {
            File(cartellaDocumentiLegacy(), nomeFile).exists()
        }
    }

    /**
     * Crea lo zip della cartella e lo salva direttamente nella cartella pubblica "Documenti"
     * del dispositivo, così resta disponibile da qualsiasi gestore file senza dover passare
     * dalla condivisione. Se "sovrascrivi" è false e il file esiste già, ne viene salvata
     * una copia separata con un nome tipo "Nome (1).zip". Ritorna true se il salvataggio
     * è andato a buon fine.
     */
    fun salvaZipInDocumenti(context: Context, nomeCartella: String, sovrascrivi: Boolean): Boolean {
        val zipFile = creaZipDiCartella(context, nomeCartella) ?: return false
        val nomeFileBase = "$nomeCartella.zip"

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver = context.contentResolver
                val collection = MediaStore.Files.getContentUri("external")

                if (sovrascrivi) {
                    val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ? AND ${MediaStore.MediaColumns.DISPLAY_NAME} = ?"
                    resolver.delete(collection, selection, arrayOf("$CARTELLA_DOCUMENTI/", nomeFileBase))
                }
                val nomeFileFinale = if (sovrascrivi) nomeFileBase else nomeDisponibileMediaStore(context, nomeFileBase)

                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, nomeFileFinale)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, CARTELLA_DOCUMENTI)
                }
                val uri: Uri = resolver.insert(collection, values) ?: return false
                resolver.openOutputStream(uri)?.use { output ->
                    FileInputStream(zipFile).use { input -> input.copyTo(output) }
                } ?: return false
                true
            } else {
                val cartellaDocumenti = cartellaDocumentiLegacy()
                if (!cartellaDocumenti.exists()) cartellaDocumenti.mkdirs()
                val nomeFileFinale = if (sovrascrivi) nomeFileBase else nomeDisponibileLegacy(cartellaDocumenti, nomeFileBase)
                val destinazione = File(cartellaDocumenti, nomeFileFinale)
                FileInputStream(zipFile).use { input ->
                    FileOutputStream(destinazione).use { output -> input.copyTo(output) }
                }
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    /** Cartella pubblica "Documenti" (a fianco di Pictures, Movies, Download...) usata su Android 9 e precedenti */
    private fun cartellaDocumentiLegacy(): File {
        return File(Environment.getExternalStorageDirectory(), CARTELLA_DOCUMENTI)
    }

    private fun esisteInMediaStore(context: Context, nomeFile: String): Boolean {
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ? AND ${MediaStore.MediaColumns.DISPLAY_NAME} = ?"
        val args = arrayOf("$CARTELLA_DOCUMENTI/", nomeFile)
        return context.contentResolver.query(
            MediaStore.Files.getContentUri("external"),
            arrayOf(MediaStore.MediaColumns._ID),
            selection,
            args,
            null
        )?.use { it.moveToFirst() } ?: false
    }

    /** Trova un nome libero tipo "Nome (1).zip", "Nome (2).zip"... controllando il MediaStore */
    private fun nomeDisponibileMediaStore(context: Context, nomeFileBase: String): String {
        var candidato = nomeFileBase
        var contatore = 1
        while (esisteInMediaStore(context, candidato)) {
            candidato = nomeConSuffisso(nomeFileBase, contatore)
            contatore++
        }
        return candidato
    }

    /** Trova un nome libero tipo "Nome (1).zip", "Nome (2).zip"... controllando il file system */
    private fun nomeDisponibileLegacy(cartella: File, nomeFileBase: String): String {
        var candidato = nomeFileBase
        var contatore = 1
        while (File(cartella, candidato).exists()) {
            candidato = nomeConSuffisso(nomeFileBase, contatore)
            contatore++
        }
        return candidato
    }

    private fun nomeConSuffisso(nomeFileBase: String, contatore: Int): String {
        val base = nomeFileBase.substringBeforeLast(".")
        val estensione = nomeFileBase.substringAfterLast(".", "")
        return if (estensione.isNotEmpty()) "$base ($contatore).$estensione" else "$base ($contatore)"
    }

    private fun aggiungiFotoAllozip(context: Context, nomeCartella: String, zos: ZipOutputStream) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_PICTURES}/$SOTTOCARTELLA/$nomeCartella/"
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
            context.contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                arrayOf(relativePath),
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.getString(nameCol)
                    val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                    try {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            zos.putNextEntry(ZipEntry(displayName))
                            input.copyTo(zos)
                            zos.closeEntry()
                        }
                    } catch (e: Exception) {
                        // salta questa foto e continua con le altre
                    }
                }
            }
        } else {
            val cartellaPubblica = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "$SOTTOCARTELLA/$nomeCartella"
            )
            cartellaPubblica.listFiles()?.forEach { file ->
                try {
                    FileInputStream(file).use { input ->
                        zos.putNextEntry(ZipEntry(file.name))
                        input.copyTo(zos)
                        zos.closeEntry()
                    }
                } catch (e: Exception) {
                    // salta questo file
                }
            }
        }
    }

    private fun aggiungiVideoAllozip(context: Context, nomeCartella: String, zos: ZipOutputStream) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = "${Environment.DIRECTORY_MOVIES}/$SOTTOCARTELLA/$nomeCartella/"
            val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME)
            val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} = ?"
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                arrayOf(relativePath),
                null
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val displayName = cursor.getString(nameCol)
                    val uri = Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString())
                    try {
                        context.contentResolver.openInputStream(uri)?.use { input ->
                            zos.putNextEntry(ZipEntry(displayName))
                            input.copyTo(zos)
                            zos.closeEntry()
                        }
                    } catch (e: Exception) {
                        // salta questo video e continua con gli altri
                    }
                }
            }
        } else {
            val cartellaPubblica = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                "$SOTTOCARTELLA/$nomeCartella"
            )
            cartellaPubblica.listFiles()?.forEach { file ->
                try {
                    FileInputStream(file).use { input ->
                        zos.putNextEntry(ZipEntry(file.name))
                        input.copyTo(zos)
                        zos.closeEntry()
                    }
                } catch (e: Exception) {
                    // salta questo file
                }
            }
        }
    }

    private fun aggiungiNotaAllozip(context: Context, nomeCartella: String, zos: ZipOutputStream) {
        val noteFile = File(context.filesDir, "$SOTTOCARTELLA/$nomeCartella/note.txt")
        if (noteFile.exists()) {
            try {
                FileInputStream(noteFile).use { input ->
                    zos.putNextEntry(ZipEntry("$nomeCartella.txt"))
                    input.copyTo(zos)
                    zos.closeEntry()
                }
            } catch (e: Exception) {
                // ignorato
            }
        }
    }
}
