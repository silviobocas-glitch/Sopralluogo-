package com.example.sopralluoghi

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider

class NotesActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NOME = "NOME_CARTELLA"
    }

    private lateinit var nomeCartella: String
    private lateinit var etNote: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notes)

        nomeCartella = intent.getStringExtra(EXTRA_NOME) ?: run {
            finish()
            return
        }

        findViewById<TextView>(R.id.tvTitoloNote).text = "Note — $nomeCartella"
        etNote = findViewById(R.id.etNote)
        etNote.setText(NotesHelper.leggiNota(this, nomeCartella))

        findViewById<android.view.View>(R.id.btnCondividiNota).setOnClickListener { condividiNota() }
    }

    override fun onPause() {
        super.onPause()
        NotesHelper.salvaNota(this, nomeCartella, etNote.text.toString())
    }

    /** Condivide direttamente il file note.txt tramite FileProvider: niente zip, così l'app
     * che riceve la condivisione (WhatsApp, email, ecc.) vede subito il testo della nota. */
    private fun condividiNota() {
        if (etNote.text.isNullOrBlank()) {
            Toast.makeText(this, "Scrivi prima una nota da condividere", Toast.LENGTH_SHORT).show()
            return
        }
        // Salva subito eventuali modifiche non ancora scritte su disco, prima di condividere
        NotesHelper.salvaNota(this, nomeCartella, etNote.text.toString())

        val file = NotesHelper.fileNota(this, nomeCartella)
        if (!file.exists()) {
            Toast.makeText(this, "Impossibile condividere la nota", Toast.LENGTH_SHORT).show()
            return
        }

        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(shareIntent, "Condividi nota"))
    }
}
