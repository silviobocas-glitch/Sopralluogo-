package com.example.sopralluoghi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File

class FolderActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NOME = "NOME_CARTELLA"
    }

    private lateinit var nomeCartella: String

    /** Zip già creato in cache, in attesa che l'utente scelga dove salvarlo. */
    private var zipInAttesaDiSalvataggio: File? = null

    private val richiestaPermessi = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { risultati ->
        if (risultati.values.all { it }) {
            avviaFotocamera()
        } else {
            Toast.makeText(this, "Serve il permesso fotocamera per continuare", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Selettore di sistema (Storage Access Framework): è l'utente a scegliere
     * cartella e nome del file quando salva lo zip sul dispositivo.
     */
    private val selettoreDestinazioneZip = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/zip")
    ) { uri -> onDestinazioneZipScelta(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_folder)

        nomeCartella = intent.getStringExtra(EXTRA_NOME) ?: run {
            finish()
            return
        }

        findViewById<TextView>(R.id.tvTitoloCartella).text = nomeCartella

        findViewById<View>(R.id.btnFotocamera).setOnClickListener { controllaPermessiEAvviaFotocamera() }

        findViewById<View>(R.id.btnVediFoto).setOnClickListener {
            val intent = Intent(this, GalleryActivity::class.java)
            intent.putExtra(GalleryActivity.EXTRA_NOME_CARTELLA, nomeCartella)
            startActivity(intent)
        }

        findViewById<View>(R.id.btnNote).setOnClickListener { apriNote() }

        findViewById<View>(R.id.btnCondividi).setOnClickListener { condividiCartella() }

        findViewById<View>(R.id.btnSalva).setOnClickListener { avviaSalvataggio() }
    }

    private fun controllaPermessiEAvviaFotocamera() {
        // Foto e video vivono nella cartella privata dell'app (nessun permesso di storage necessario):
        // servono solo i permessi di fotocamera e microfono.
        val permessiNecessari = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)

        val mancanti = permessiNecessari.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (mancanti.isEmpty()) {
            avviaFotocamera()
        } else {
            richiestaPermessi.launch(mancanti.toTypedArray())
        }
    }

    private fun avviaFotocamera() {
        val intent = Intent(this, CameraActivity::class.java)
        intent.putExtra(CameraActivity.EXTRA_NOME_SOPRALLUOGO, nomeCartella)
        startActivity(intent)
    }

    /** Le note vivono nella cartella privata dell'app (vedi NotesHelper/StorageHelper):
     * non serve alcun permesso per aprirle, su nessuna versione di Android. */
    private fun apriNote() {
        val intent = Intent(this, NotesActivity::class.java)
        intent.putExtra(NotesActivity.EXTRA_NOME, nomeCartella)
        startActivity(intent)
    }

    private fun condividiCartella() {
        Toast.makeText(this, "Preparo il file da condividere...", Toast.LENGTH_SHORT).show()
        Thread {
            val zipFile = ZipHelper.creaZipDiCartella(this, nomeCartella)
            runOnUiThread {
                if (zipFile != null) {
                    val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", zipFile)
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/zip"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    startActivity(Intent.createChooser(shareIntent, "Condividi $nomeCartella"))
                } else {
                    Toast.makeText(this, "Errore nella creazione dello zip", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Prepara lo zip e poi apre il selettore di sistema per far scegliere all'utente dove salvarlo. */
    private fun avviaSalvataggio() {
        Toast.makeText(this, "Preparo il file da salvare...", Toast.LENGTH_SHORT).show()
        Thread {
            val zipFile = ZipHelper.creaZipDiCartella(this, nomeCartella)
            runOnUiThread {
                if (zipFile != null) {
                    zipInAttesaDiSalvataggio = zipFile
                    selettoreDestinazioneZip.launch("$nomeCartella.zip")
                } else {
                    Toast.makeText(this, "Errore nella creazione dello zip", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Chiamato quando l'utente ha scelto cartella e nome file nel selettore di sistema. */
    private fun onDestinazioneZipScelta(uri: Uri?) {
        val zipFile = zipInAttesaDiSalvataggio
        zipInAttesaDiSalvataggio = null

        if (uri == null) {
            // L'utente ha annullato la scelta della destinazione.
            return
        }
        if (zipFile == null) {
            Toast.makeText(this, "Errore nel salvataggio dello zip", Toast.LENGTH_LONG).show()
            return
        }

        Toast.makeText(this, "Salvo il file...", Toast.LENGTH_SHORT).show()
        Thread {
            val riuscito = ZipHelper.scriviZipSuUri(this, zipFile, uri)
            runOnUiThread {
                if (riuscito) {
                    Toast.makeText(this, "Zip salvato", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Errore nel salvataggio dello zip", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }
}
