package com.example.sopralluoghi

import android.content.Context

/** Salva l'elenco dei sopralluoghi creati (nomi cartella) nelle SharedPreferences */
object PrefsHelper {
    private const val PREFS = "sopralluoghi_prefs"
    private const val KEY_LISTA = "lista_nomi"
    private const val SEPARATORE = "\u0001"

    fun getLista(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LISTA, "") ?: ""
        return if (raw.isEmpty()) emptyList() else raw.split(SEPARATORE)
    }

    /** Aggiunge il nome in cima alla lista (più recente prima). Se esiste già, lo sposta in cima. */
    fun aggiungiOSpostaInCima(context: Context, nome: String) {
        val lista = getLista(context).toMutableList()
        lista.remove(nome)
        lista.add(0, nome)
        salvaLista(context, lista)
    }

    fun rimuovi(context: Context, nome: String) {
        val lista = getLista(context).toMutableList()
        lista.remove(nome)
        salvaLista(context, lista)
    }

    private fun salvaLista(context: Context, lista: List<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_LISTA, lista.joinToString(SEPARATORE))
            .apply()
    }
}

/** Elimina definitivamente foto, video e note di un sopralluogo: vivono tutti nella stessa
 * cartella privata dell'app (StorageHelper/NotesHelper), quindi eliminando la cartella non
 * ne resta traccia sul telefono. */
object GestioneCartelle {
    fun eliminaTutto(context: Context, nomeCartella: String) {
        StorageHelper.eliminaCartellaSopralluogo(context, nomeCartella)
    }
}
