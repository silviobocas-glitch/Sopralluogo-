package com.example.sopralluoghi

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.concurrent.Executors

/** Rappresenta un elemento della galleria: foto o video, sempre come File nella cartella privata dell'app
 * (il campo uri è mantenuto solo per compatibilità con il codice che lo consuma, ma non viene più usato) */
data class FotoItem(
    val uri: Uri?,
    val file: File?,
    val numero: Int,
    val nomeVisualizzato: String,
    val isVideo: Boolean
)

/**
 * Contenitore in memoria condiviso tra GalleryActivity e FullImageActivity: evita di dover
 * serializzare tutta la lista (foto+video) in un Intent solo per permettere lo scorrimento
 * avanti/indietro nell'anteprima a schermo intero.
 */
object GalleriaCorrente {
    var elementi: List<FotoItem> = emptyList()
}

class GalleryActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_NOME_CARTELLA = "NOME_CARTELLA"
    }

    private lateinit var nomeCartella: String
    private val elencoFoto = mutableListOf<FotoItem>()
    private lateinit var adapter: PhotoAdapter
    private val executor = Executors.newFixedThreadPool(3)

    /** Elementi attualmente selezionati (tap prolungato per attivare la modalità selezione,
     * poi tap semplice per aggiungere/togliere altri elementi). Vuoto = modalità disattiva. */
    private val selezionati = mutableSetOf<FotoItem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gallery)

        nomeCartella = intent.getStringExtra(EXTRA_NOME_CARTELLA) ?: ""

        findViewById<TextView>(R.id.tvTitoloGalleria).text = nomeCartella
        val rv = findViewById<RecyclerView>(R.id.rvFoto)
        rv.layoutManager = GridLayoutManager(this, 3)
        adapter = PhotoAdapter(
            elenco = elencoFoto,
            executor = executor,
            selezionati = selezionati,
            onClick = { fotoItem -> alClickElemento(fotoItem) },
            onLongClick = { fotoItem -> toggleSelezione(fotoItem) }
        )
        rv.adapter = adapter

        findViewById<View>(R.id.btnAnnullaSelezione).setOnClickListener { annullaSelezione() }
        findViewById<View>(R.id.btnCondividiSelezionati).setOnClickListener { condividiSelezionati() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (selezionati.isNotEmpty()) {
                    annullaSelezione()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })

        caricaFoto()
    }

    override fun onResume() {
        super.onResume()
        // Ricarica ogni volta che si torna qui (es. dopo aver eliminato una foto)
        caricaFoto()
    }

    private fun caricaFoto() {
        Thread {
            val lista = mutableListOf<FotoItem>()
            try {
                val cartella = StorageHelper.cartellaSopralluogo(this, nomeCartella)
                cartella.listFiles()?.forEach { file ->
                    if (file.name.equals("note.txt", ignoreCase = true)) return@forEach
                    val numero = estraiNumero(file.name) ?: return@forEach
                    val isVideo = file.extension.equals("mp4", ignoreCase = true)
                    lista.add(FotoItem(null, file, numero, file.name, isVideo))
                }
            } catch (e: Exception) {
                // lista resta vuota o parziale
            }

            lista.sortBy { it.numero }

            runOnUiThread {
                // Annulla un'eventuale selezione in corso: dopo un ricaricamento gli elementi
                // selezionati potrebbero non esistere più (es. una foto è stata eliminata).
                annullaSelezione()
                elencoFoto.clear()
                elencoFoto.addAll(lista)
                adapter.notifyDataSetChanged()
                findViewById<TextView>(R.id.tvNumeroFoto).text = "${lista.size} elementi"
                findViewById<View>(R.id.tvNessunaFoto).visibility =
                    if (lista.isEmpty()) View.VISIBLE else View.GONE
            }
        }.start()
    }

    /**
     * Estrae il numero progressivo dal nome del file (es. "Castano 4.jpg" -> 4).
     * Non è sensibile a maiuscole/minuscole o spazi extra, e ignora eventuali suffissi
     * come "(1)" che Android aggiunge da solo se esiste già un file con lo stesso nome:
     * un confronto troppo rigido faceva sì che la numerazione sparisse (mostrando sempre 0)
     * appena il nome non coincideva byte per byte.
     */
    private fun estraiNumero(nomeFile: String): Int? {
        val senzaEstensione = nomeFile.substringBeforeLast(".").trim()
        val regex = Regex("^${Regex.escape(nomeCartella.trim())}\\s+(\\d+)", RegexOption.IGNORE_CASE)
        return regex.find(senzaEstensione)?.groupValues?.get(1)?.toIntOrNull()
    }

    private fun apriElemento(fotoItem: FotoItem) {
        val indice = elencoFoto.indexOf(fotoItem)
        if (indice == -1) return

        GalleriaCorrente.elementi = elencoFoto.toList()

        val intent = Intent(this, FullImageActivity::class.java)
        intent.putExtra(FullImageActivity.EXTRA_INDICE, indice)
        startActivity(intent)
    }

    /** Tap semplice: se siamo già in modalità selezione seleziona/deseleziona l'elemento,
     * altrimenti lo apre a schermo intero come al solito. */
    private fun alClickElemento(fotoItem: FotoItem) {
        if (selezionati.isNotEmpty()) {
            toggleSelezione(fotoItem)
        } else {
            apriElemento(fotoItem)
        }
    }

    /** Aggiunge o toglie un elemento dalla selezione (attivata dal tap prolungato). */
    private fun toggleSelezione(fotoItem: FotoItem) {
        if (!selezionati.remove(fotoItem)) {
            selezionati.add(fotoItem)
        }
        adapter.notifyDataSetChanged()
        aggiornaBarraSelezione()
    }

    private fun annullaSelezione() {
        if (selezionati.isEmpty()) return
        selezionati.clear()
        adapter.notifyDataSetChanged()
        aggiornaBarraSelezione()
    }

    private fun aggiornaBarraSelezione() {
        val inSelezione = selezionati.isNotEmpty()
        findViewById<View>(R.id.barraSuperiore).visibility = if (inSelezione) View.GONE else View.VISIBLE
        findViewById<View>(R.id.barraSelezione).visibility = if (inSelezione) View.VISIBLE else View.GONE
        if (inSelezione) {
            val n = selezionati.size
            findViewById<TextView>(R.id.tvNumeroSelezionati).text =
                if (n == 1) "1 selezionato" else "$n selezionati"
        }
    }

    /** Condivide direttamente i file selezionati (foto e/o video), uno per uno tramite
     * FileProvider: niente zip, così l'app che riceve la condivisione (WhatsApp, email, ecc.)
     * vede subito i singoli file. */
    private fun condividiSelezionati() {
        if (selezionati.isEmpty()) return

        val uris = ArrayList<Uri>()
        var contieneVideo = false
        var contieneFoto = false
        for (item in selezionati) {
            val file = item.file ?: continue
            uris.add(FileProvider.getUriForFile(this, "$packageName.fileprovider", file))
            if (item.isVideo) contieneVideo = true else contieneFoto = true
        }
        if (uris.isEmpty()) return

        // Tipo MIME: se sono tutti dello stesso genere usiamo quello specifico, altrimenti generico
        val tipoMime = when {
            contieneVideo && contieneFoto -> "*/*"
            contieneVideo -> "video/mp4"
            else -> "image/jpeg"
        }

        val shareIntent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = tipoMime
                putExtra(Intent.EXTRA_STREAM, uris[0])
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = tipoMime
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }

        val messaggio = if (uris.size == 1) "Condividi elemento" else "Condividi ${uris.size} elementi"
        startActivity(Intent.createChooser(shareIntent, messaggio))
        annullaSelezione()
    }
}

/** Adapter della griglia: carica le miniature in background con una piccola cache in memoria */
class PhotoAdapter(
    private val elenco: List<FotoItem>,
    private val executor: java.util.concurrent.ExecutorService,
    private val selezionati: MutableSet<FotoItem>,
    private val onClick: (FotoItem) -> Unit,
    private val onLongClick: (FotoItem) -> Unit
) : RecyclerView.Adapter<PhotoAdapter.PhotoViewHolder>() {

    private val cache = HashMap<String, Bitmap>()

    inner class PhotoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivFoto: ImageView = itemView.findViewById(R.id.ivFoto)
        val tvNumero: TextView = itemView.findViewById(R.id.tvNumeroFotoCella)
        val ivIconaVideo: TextView = itemView.findViewById(R.id.ivIconaVideo)
        val vScrimSelezione: View = itemView.findViewById(R.id.vScrimSelezione)
        val ivSpuntaSelezione: ImageView = itemView.findViewById(R.id.ivSpuntaSelezione)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PhotoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_photo, parent, false)
        return PhotoViewHolder(view)
    }

    override fun onBindViewHolder(holder: PhotoViewHolder, position: Int) {
        val fotoItem = elenco[position]
        holder.tvNumero.text = fotoItem.numero.toString()
        holder.ivFoto.setImageBitmap(null)
        holder.ivIconaVideo.visibility = if (fotoItem.isVideo) View.VISIBLE else View.GONE
        holder.itemView.setOnClickListener { onClick(fotoItem) }
        holder.itemView.setOnLongClickListener { onLongClick(fotoItem); true }

        val inModalitaSelezione = selezionati.isNotEmpty()
        val selezionata = selezionati.contains(fotoItem)
        holder.vScrimSelezione.visibility = if (selezionata) View.VISIBLE else View.GONE
        holder.ivSpuntaSelezione.visibility = if (inModalitaSelezione) View.VISIBLE else View.GONE
        holder.ivSpuntaSelezione.setImageResource(
            if (selezionata) R.drawable.ic_selezione_piena else R.drawable.ic_selezione_vuota
        )

        val chiaveCache = fotoItem.uri?.toString() ?: fotoItem.file?.absolutePath ?: return
        cache[chiaveCache]?.let {
            holder.ivFoto.setImageBitmap(it)
            return
        }

        executor.execute {
            val bitmap = if (fotoItem.isVideo) {
                caricaMiniaturaVideo(holder.itemView.context, fotoItem)
            } else {
                ImmagineUtils.caricaBitmapCorretto(
                    holder.itemView.context, fotoItem.uri, fotoItem.file, inSampleSize = 4
                )
            }

            if (bitmap != null) {
                cache[chiaveCache] = bitmap
                holder.itemView.post {
                    if (holder.adapterPosition == position) {
                        holder.ivFoto.setImageBitmap(bitmap)
                    }
                }
            }
        }
    }

    private fun caricaMiniaturaVideo(context: android.content.Context, fotoItem: FotoItem): Bitmap? {
        return try {
            val retriever = android.media.MediaMetadataRetriever()
            if (fotoItem.uri != null) {
                retriever.setDataSource(context, fotoItem.uri)
            } else if (fotoItem.file != null) {
                retriever.setDataSource(fotoItem.file.absolutePath)
            }
            val frame = retriever.getFrameAtTime(0)
            retriever.release()
            frame
        } catch (e: Exception) {
            null
        }
    }

    override fun getItemCount(): Int = elenco.size
}
